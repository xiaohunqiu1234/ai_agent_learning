"""端到端演练脚本：扮演 Dify，按顺序调用 MCP 服务上的工具。

它演示的不只是"能调通"，而是每一类返回值长什么样：
    [1] tools/list         —— 工具清单就是 LLM 能看到的"菜单"
    [2] 健康检查            —— 排障第一步
    [3] 同步工具成功         —— 一句话拿到结果
    [4] 本地校验失败         —— BAD_ARGS 不会打到上游
    [5] 上游 4xx            —— token 错，错误被翻译成结构化信封
    [6] 异步 wait=false     —— 确认后台接手就断开，再轮询到完成
    [7] 异步 wait=true      —— 一直读到结束，能拿到结果文件 ID
    [8] 断得太早            —— TASK_CANCELLED（最重要的反例）

单独运行（需先起 sample_upstream 与 MCP 服务）：
    python -m apps.mcp_demo.demo_client
"""

from __future__ import annotations

import asyncio
import json
import os
import time

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

MCP_URL = os.getenv("MCP_URL", "http://127.0.0.1:7301/mcp")
TOKEN = os.getenv("SAMPLE_TOKEN", "demo-token")
RESOURCE_ID = "res-demo-001"


# ───────────────────────────── 输出小工具 ─────────────────────────────

def step(index: int, total: int, title: str) -> float:
    print(f"\n[{index}/{total}] {title}")
    print("─" * 62)
    return time.monotonic()


def show(data: dict) -> None:
    """打印精简后的结果：长文本只留前 2 行，避免刷屏。"""
    out = {}
    for key, value in data.items():
        if isinstance(value, str) and len(value) > 160:
            head = "\n".join(value.splitlines()[:2])
            out[key] = f"{head} …（共 {len(value)} 字）"
        elif key == "items" and isinstance(value, list):
            out[key] = f"[{len(value)} 条]"
        else:
            out[key] = value
    print(json.dumps(out, ensure_ascii=False, indent=2))


def payload(result) -> dict:
    """MCP 的 CallToolResult → 工具返回的 dict。

    官方 SDK 在工具有结构化返回时会填 structuredContent；否则退回解析文本内容。
    """
    structured = getattr(result, "structuredContent", None)
    if structured:
        return structured
    for item in result.content:
        text = getattr(item, "text", None)
        if text:
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"raw": text}
    return {}


async def call(session: ClientSession, name: str, args: dict | None = None) -> dict:
    return payload(await session.call_tool(name, args or {}))


# ───────────────────────────── 演练主流程 ─────────────────────────────

async def run(url: str = MCP_URL) -> int:
    total = 8
    print(f"连接 MCP 服务：{url}")

    async with streamablehttp_client(url, timeout=30, sse_read_timeout=300) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # [1] 工具清单：name + description 就是 LLM 选择工具的全部依据
            step(1, total, "tools/list —— 看 LLM 能看见什么")
            tools = await session.list_tools()
            for tool in tools.tools:
                first_line = (tool.description or "").splitlines()[0] if tool.description else ""
                print(f"  · {tool.name:16s} {first_line}")
            print("\n  ↑ 这些 description 会以 token 形式进 LLM 上下文，写法等于提示词工程")

            # [2] 健康检查：任何联调都从这里开始
            step(2, total, "健康检查 —— 确认上游可达")
            show(await call(session, "sync_health"))

            # [3] 同步工具成功路径
            t0 = step(3, total, "同步工具 —— 一次调用一次结果")
            show(await call(session, "sync_call", {"input": "hello mcp", "token": TOKEN}))
            print(f"  耗时 {time.monotonic() - t0:.1f}s")

            # [4] 本地校验：空参数在 MCP 层就挡掉，没有打上游
            step(4, total, "本地校验 —— 空 input，不浪费上游调用")
            show(await call(session, "sync_call", {"input": "", "token": TOKEN}))

            # [5] 上游 4xx：错误被归一成信封，message 来自上游
            step(5, total, "上游 4xx —— token 错误，错误不再是一句『调用失败』")
            show(await call(session, "sync_call", {"input": "hello", "token": "wrong-token"}))

            # [6] 异步：确认后台接手就断开，再轮询
            t0 = step(6, total, "异步 wait=false —— 拿到 job_id 就断开，再轮询到完成")
            started = await call(session, "task_submit", {
                "resource_id": RESOURCE_ID,
                "token": TOKEN,
                "wait": False,
            })
            show(started)
            print(f"  耗时 {time.monotonic() - t0:.1f}s（没等任务跑完，只等后台接手）")

            task_id = started.get("task_id", "")
            if not task_id:
                print("  ✗ 没拿到 task_id，后续步骤跳过")
                return 1

            final: dict = {}
            for i in range(40):
                final = await call(session, "task_status", {"task_id": task_id})
                print(f"  {i + 1:2d}. status={final.get('status'):10s} "
                      f"job_id={final.get('job_id', '')[:8]:8s} "
                      f"live={(final.get('live') or {}).get('progress')}")
                if final.get("status") in ("completed", "failed", "cancelled", "error"):
                    break
                await asyncio.sleep(1)
            show({k: final.get(k) for k in ("task_id", "status", "item_count", "truncated")})

            # [7] wait=true：这条路才会生成结果文件
            t0 = step(7, total, "异步 wait=true —— 读到结束，可拿到结果文件 ID")
            show(await call(session, "task_submit", {
                "resource_id": RESOURCE_ID,
                "token": TOKEN,
                "wait": True,
                "wait_timeout": 120,
            }))
            print(f"  耗时 {time.monotonic() - t0:.1f}s")

            # [8] 反例：在 job 提交前就断开，任务会被上游取消
            step(8, total, "反例 —— submit_timeout 太小，断开过早会取消任务")
            early = await call(session, "task_submit", {
                "resource_id": RESOURCE_ID,
                "token": TOKEN,
                "wait": False,
                "submit_timeout": 2,
            })
            show(early)
            early_task = early.get("task_id", "")
            if early_task:
                after = await call(session, "task_status", {"task_id": early_task})
                print("\n  立刻回查这个任务：")
                show({k: after.get(k) for k in ("task_id", "status", "job_id", "hint")})
            print("\n  ↑ 返回 TASK_CANCELLED / SUBMIT_TIMEOUT 且 job_id 为空 ——")
            print("    连接断在 job 提交前，任务根本没提交。")
            print("    这就是 wait=false 必须用 probe 确认『后台已接手』才断开的原因。")

    print("\n演练结束。下一步：把 tools/ 里的路径和字段换成你自己的服务。")
    return 0


def main() -> int:
    return asyncio.run(run())


if __name__ == "__main__":
    raise SystemExit(main())
