"""MCP 封装示例（不含任何业务语义）。

两个通用工具范式：
    · 同步 JSON：tools/sync_api.py
    · SSE + 后台任务：tools/task_api.py

换成自己的服务时，只改 tools/ 下的路径与字段，结构不用动。
"""
