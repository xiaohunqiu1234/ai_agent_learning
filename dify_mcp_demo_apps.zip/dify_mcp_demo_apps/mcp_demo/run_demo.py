"""一键跑通：起示例上游 → 起 MCP 服务 → 跑演练 → 收尾。

    cd agent_learning
    python3 -m apps.mcp_demo.run_demo            # 跑完自动关闭
    python3 -m apps.mcp_demo.run_demo --keep     # 保留服务，供 Dify 连接
"""

from __future__ import annotations

import argparse
import asyncio
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

# 项目根（agent_learning）：apps/mcp_demo/run_demo.py → parents[2]
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def port_open(port: int, host: str = "127.0.0.1", timeout: float = 0.4) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        return sock.connect_ex((host, port)) == 0


def wait_port(port: int, name: str, timeout: float = 20.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if port_open(port):
            print(f"  ✓ {name} 已就绪（127.0.0.1:{port}）")
            return
        time.sleep(0.2)
    raise SystemExit(f"✗ {name} 在 {timeout:.0f}s 内没有起来，请单独启动看报错日志")


def child_env(extra: dict[str, str]) -> dict[str, str]:
    env = os.environ.copy()
    # 子进程也要能 import apps.*，与父进程解耦
    env["PYTHONPATH"] = str(ROOT) + (
        os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else ""
    )
    env.setdefault("PYTHONUNBUFFERED", "1")
    env.update(extra)
    return env


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="MCP 封装 demo 一键运行")
    parser.add_argument("--mcp-port", type=int, default=int(os.getenv("MCP_PORT", "7301")))
    parser.add_argument("--upstream-port", type=int,
                        default=int(os.getenv("UPSTREAM_PORT", "7300")))
    parser.add_argument("--submit-delay", type=float, default=4.0,
                        help="模拟解析/预处理耗时（job 提交前）")
    parser.add_argument("--total-delay", type=float, default=10.0,
                        help="模拟后台任务总耗时")
    parser.add_argument("--keep", action="store_true", help="演练后保留服务，便于接 Dify")
    parser.add_argument("--skip-demo", action="store_true", help="只起服务，不跑演练")
    args = parser.parse_args(argv)

    for port, name in ((args.upstream_port, "示例上游"), (args.mcp_port, "MCP 服务")):
        if port_open(port):
            print(f"✗ 端口 {port} 已被占用（{name}）。"
                  f"换端口：--mcp-port/--upstream-port，或先关掉旧进程")
            return 1

    procs: list[subprocess.Popen] = []
    print("\n▶ 启动示例上游（同步 JSON + 异步 SSE）…")
    upstream = subprocess.Popen(
        [
            sys.executable, "-m", "uvicorn", "apps.mcp_demo.sample_upstream:app",
            "--host", "127.0.0.1", "--port", str(args.upstream_port),
            "--log-level", "warning",
        ],
        cwd=str(ROOT),
        env=child_env({
            "SAMPLE_SUBMIT_DELAY": str(args.submit_delay),
            "SAMPLE_TOTAL_DELAY": str(args.total_delay),
        }),
    )
    procs.append(upstream)

    print("▶ 启动 MCP 服务…")
    mcp_proc = subprocess.Popen(
        [sys.executable, "-u", "-m", "apps.mcp_demo.main"],
        cwd=str(ROOT),
        env=child_env({
            "MCP_PORT": str(args.mcp_port),
            "MCP_HOST": "127.0.0.1",
            # 演练时压低日志噪音；想看每个请求改成 INFO
            "MCP_LOG_LEVEL": os.getenv("MCP_LOG_LEVEL", "WARNING"),
            "UPSTREAM_SYNC_BASE": f"http://127.0.0.1:{args.upstream_port}",
            "UPSTREAM_TASK_BASE": f"http://127.0.0.1:{args.upstream_port}",
        }),
    )
    procs.append(mcp_proc)

    code = 0
    try:
        wait_port(args.upstream_port, "示例上游")
        wait_port(args.mcp_port, "MCP 服务")

        url = f"http://127.0.0.1:{args.mcp_port}/mcp"
        if not args.skip_demo:
            from apps.mcp_demo.demo_client import run

            code = asyncio.run(run(url))

        if args.keep or args.skip_demo:
            print("\n服务保持运行：")
            print(f"  MCP 端点    {url}")
            print(f"  示例上游    http://127.0.0.1:{args.upstream_port}")
            print(f"  Dify 里填   http://<宿主机IP>:{args.mcp_port}/mcp")
            print("\n按 Ctrl-C 结束。")
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        print("\n收到 Ctrl-C，正在关闭…")
    finally:
        for proc in procs:
            if proc.poll() is None:
                proc.terminate()
        for proc in procs:
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()

    return code


if __name__ == "__main__":
    raise SystemExit(main())
