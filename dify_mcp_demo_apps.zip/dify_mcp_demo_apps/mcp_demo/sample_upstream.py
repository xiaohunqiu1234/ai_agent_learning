"""示例上游服务：只用来把 MCP 封装跑通，不含任何业务语义。

提供两种最常见的接口形态：

    1. 同步 JSON：POST /api/sync
       请求进来、跑一会儿、一次性返回结果。

    2. SSE + 后台任务：POST /api/tasks/upload
       · 响应头带 X-Task-Id，正文是进度事件流；
       · 前 4 秒的解析跑在"当前请求进程内"（此刻断开连接 = 任务被取消，没有 job_id）；
       · 4 秒后才有 job_id，并且只写在 GET /api/tasks/{id} 的 meta 里；
       · SSE 事件里只出现被截断到 12 位的任务 ID；
       · 结果文件 ID 只在流收尾阶段生成。

这些时序是刻意保留的：只有看到"何时断开安全、何时断开等于取消"，
才会明白 MCP 封装里为什么需要 probe 这种侧信道。

启动（通常由 run_demo.py 自动拉起）：
    python -m uvicorn apps.mcp_demo.sample_upstream:app --port 7300
可调参数（秒）：
    SAMPLE_SUBMIT_DELAY=4    提交后台任务之前的耗时（解析/预处理）
    SAMPLE_TOTAL_DELAY=10    后台任务总耗时
    SAMPLE_SYNC_DELAY=0.8    同步接口耗时
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from typing import Any

from fastapi import FastAPI, Form, Request
from fastapi.responses import JSONResponse, StreamingResponse

SUBMIT_DELAY = float(os.getenv("SAMPLE_SUBMIT_DELAY", "4"))
TOTAL_DELAY = float(os.getenv("SAMPLE_TOTAL_DELAY", "10"))
SYNC_DELAY = float(os.getenv("SAMPLE_SYNC_DELAY", "0.8"))
VALID_TOKEN = os.getenv("SAMPLE_TOKEN", "demo-token")

app = FastAPI(title="Sample upstream (MCP demo)", version="1.0")

# 任务表放内存：demo 只需要"能按时间推进状态"
TASKS: dict[str, dict[str, Any]] = {}


def _now() -> float:
    return time.monotonic()


def _sse(obj: dict) -> str:
    """SSE 帧格式：data: <json> \\n\\n。中文不转义，便于人眼看事件。"""
    return "data: " + json.dumps(obj, ensure_ascii=False) + "\n\n"


def _healthy(service: str) -> dict:
    return {"status": "ok", "service": service, "sample": True}


def _refresh(task: dict) -> None:
    """按时间轴推进任务状态，模拟"后台任务独立于 SSE 连接继续跑"。

    demo 没有真实后台进程，用"开始时间 + 偏移"推导状态。
    一旦 SSE 在 job 提交前断开，任务被标记 cancelled，此后不会再变成 completed。
    """
    if task.get("cancelled"):
        task["status"] = "cancelled"
        return
    elapsed = _now() - task["started"]
    if not task.get("job_id"):
        task["status"] = "uploaded"
        return
    if elapsed >= TOTAL_DELAY:
        task["status"] = "completed"
        if not task.get("output"):
            task["output"] = _build_output(task)
            task["item_count"] = 5
            task["result_file_id"] = [f"result-{task['task_id']}"]
            task["result_file_url"] = (
                f"http://127.0.0.1:7300/files/{task['task_id']}-result.txt"
            )
            task["download_url"] = f"http://127.0.0.1:7300/files/{task['task_id']}.txt"
    else:
        task["status"] = "processing"


def _build_output(task: dict) -> str:
    """结果文本。SAMPLE_REPEAT 调大可用来验证截断逻辑。"""
    repeat = int(os.getenv("SAMPLE_REPEAT", "1"))
    part = (
        f"【示例】任务 {task['task_id']} 处理完成，共 5 项。\n"
        "这是一段示例输出，用来演示长文本截断；换成自己的服务时，这里就是真实结果。"
    )
    return "\n".join(part for _ in range(max(repeat, 1)))


@app.get("/")
async def root() -> dict:
    return {"ok": True, "service": "sample-upstream", "tasks": len(TASKS)}


# ───────────────────────── 形态一：同步 JSON ─────────────────────────

@app.get("/api/health")
async def sync_health() -> dict:
    return _healthy("sync")


@app.post("/api/sync")
async def sync(request: Request) -> JSONResponse:
    """同步接口：一次请求一次响应。"""
    payload = await request.json()
    token = str(payload.get("token") or "")
    text = str(payload.get("input") or "")

    # 三种错误分支，用来练习"上游 4xx → 结构化错误"
    if token != VALID_TOKEN:
        return JSONResponse(
            status_code=401,
            content={"code": 401, "message": "token 无效或已过期"},
        )
    if not text:
        return JSONResponse(
            status_code=400,
            content={"code": 400, "message": "input 不能为空"},
        )
    if text.startswith("missing"):
        return JSONResponse(
            status_code=404,
            content={"code": 404, "message": f"资源不存在：{text[:20]}"},
        )

    await asyncio.sleep(SYNC_DELAY)  # 模拟处理耗时，让"同步阻塞"能被感知
    return JSONResponse(
        status_code=200,
        content={
            "code": 200,
            "data": {
                "output": f"已处理 {len(text)} 字：{text[:60]}",
                "length": len(text),
            },
        },
    )


# ─────────────────── 形态二：SSE + 后台任务 ───────────────────

@app.get("/api/tasks/health")
async def task_health() -> dict:
    return {**_healthy("task"), "background_job": "ok"}


@app.post("/api/tasks/upload")
async def tasks_upload(
    use_resource: str = Form(""),
    resource_id: str = Form(""),
    token: str = Form(""),
    input: str = Form(""),
) -> Any:
    """上传即处理：响应头给 task_id，正文是 SSE 进度流。"""
    if token != VALID_TOKEN:
        return JSONResponse(
            status_code=401,
            content={"code": 401, "message": "token 无效：无法读取资源"},
        )
    if use_resource != "true" or not resource_id:
        return JSONResponse(
            status_code=400,
            content={"code": 400, "message": "NO_RESOURCE：缺少资源 ID"},
        )

    task_id = uuid.uuid4().hex[:12]
    TASKS[task_id] = {
        "task_id": task_id,
        "started": _now(),
        "job_id": "",
        "status": "uploaded",
        "cancelled": False,
        "output": "",
        "item_count": 0,
        "result_file_id": [],
        "result_file_url": "",
        "download_url": "",
        "resource_id": resource_id,
        "input": input,
    }
    return StreamingResponse(
        _upload_events(TASKS[task_id]),
        media_type="text/event-stream",
        headers={
            "X-Task-Id": task_id,          # 任务 ID 只在响应头，很容易漏
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",     # 关掉 nginx 缓冲，否则事件会被攒起来
        },
    )


async def _upload_events(task: dict):
    """SSE 生成器：演示"解析 → 提交 → 后台执行 → 收尾"的时序。

    重点：
      1. job_id 出现前，一切都在本进程内，连接一断生成器就被取消；
      2. job_id 只写进 meta，SSE 里只发 12 位截断 ID；
      3. 被取消时要标记 cancelled，让调用方能在 status 里看见。
    """
    task_id = task["task_id"]
    submitted = False
    completed = False
    last_comment = _now()
    tick = 0

    try:
        yield _sse({"status": "started", "progress": "开始处理请求", "done": False})
        while True:
            elapsed = _now() - task["started"]
            tick += 1

            # ── 阶段 1：job 提交前的"本地"处理 ──
            if not submitted and elapsed < SUBMIT_DELAY:
                if tick == 2:
                    yield _sse({"status": "processing", "progress": "正在解析资源…", "done": False})
                elif tick == 4:
                    yield _sse({"status": "processing", "progress": "预处理完成", "done": False})
                elif tick >= 6:
                    yield _sse({"status": "processing", "progress": "正在提交任务…", "done": False})
                # 穿插 SSE 注释行：客户端必须跳过以 ":" 开头的行
                if _now() - last_comment > 1.5:
                    last_comment = _now()
                    yield ": keep-alive\n\n"
                await asyncio.sleep(0.5)
                continue

            # ── 阶段 2：提交给后台任务引擎，此后断开才是安全的 ──
            if not submitted:
                submitted = True
                task["job_id"] = uuid.uuid4().hex[:16]
                task["status"] = "processing"
                # 故意只给截断 ID：常见设计，完整值只能查 meta
                yield _sse({
                    "status": "processing",
                    "progress": f"任务已提交，任务ID: {task['job_id'][:12]}",
                    "done": False,
                })
                await asyncio.sleep(0.5)
                continue

            # ── 阶段 3：后台任务推进，SSE 只做进度转发 ──
            _refresh(task)
            if task["status"] == "completed":
                completed = True
                yield _sse({
                    "status": "completed",
                    "progress": "处理完成，正在生成结果文件…",
                    "item_count": task.get("item_count", 0),
                    "done": True,
                })
                yield "data: [DONE]\n\n"
                return

            progress = int(min(99, (elapsed - SUBMIT_DELAY) / max(TOTAL_DELAY - SUBMIT_DELAY, 0.1) * 100))
            yield _sse({
                "status": "processing",
                "progress": f"处理中 {progress}%",
                "job_id": task["job_id"],
                "done": False,
            })
            await asyncio.sleep(0.8)

    except asyncio.CancelledError:
        # 客户端断开：Starlette 会取消这个生成器
        raise
    finally:
        if not submitted:
            task["cancelled"] = True
            task["status"] = "cancelled"
            task["output"] = "客户端在 job 提交前断开，任务被取消"
        elif completed:
            _refresh(task)


@app.get("/api/tasks/{task_id}")
async def task_meta(task_id: str) -> JSONResponse:
    """任务元数据：job_id / 状态 / 结果都在这里，SSE 断了靠它续查。"""
    task = TASKS.get(task_id)
    if not task:
        return JSONResponse(
            status_code=404,
            content={"code": 404, "message": f"任务不存在：{task_id}"},
        )

    _refresh(task)
    elapsed = _now() - task["started"]
    data = {
        "task_id": task_id,
        "status": task["status"],
        "job_id": task.get("job_id") or "",
        "item_count": task.get("item_count") or 0,
        "result_file_id": task.get("result_file_id") or [],
        "result_file_url": task.get("result_file_url") or "",
        "download_url": task.get("download_url") or "",
        "output": task.get("output") or "",
    }
    live = None
    if task.get("job_id") and task["status"] == "processing":
        live = {
            "job_id": task["job_id"],
            "progress": int(min(99, (elapsed - SUBMIT_DELAY) / max(TOTAL_DELAY - SUBMIT_DELAY, 0.1) * 100)),
            "elapsed_seconds": round(elapsed, 1),
        }
    return JSONResponse(
        status_code=200,
        content={
            "code": 200,
            "data": data,
            "live": live,
            "resumable": bool(task.get("job_id")),
            "hint": "" if task["status"] != "cancelled"
                    else "任务在 job 提交前被断开，未真正提交；请重新调用 task_submit",
        },
    )


@app.get("/api/tasks")
async def task_list() -> JSONResponse:
    rows = []
    for task in sorted(TASKS.values(), key=lambda t: t["started"], reverse=True):
        _refresh(task)
        rows.append({
            "task_id": task["task_id"],
            "status": task["status"],
            "job_id": task.get("job_id") or "",
            "item_count": task.get("item_count") or 0,
        })
    return JSONResponse(status_code=200, content={"code": 200, "data": rows})
