"""最小可运行 MCP 服务（约 30 行）：只有一个工具，用来先验证协议层通不通。

启动：
    python -m apps.mcp_demo.minimal_example        # http://127.0.0.1:7399/mcp

它和正式入口 main.py 的差别只有两点：
    · 工具直接写在本文件里（正式版用 tools/ 分模块 + 注册中心）；
    · 没有公共层（正式版把错误、超时、截断收进 common.py）。

建议顺序：先让这个文件被客户端调通，再看 main.py + tools/。
"""

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "minimal-demo",
    host="127.0.0.1",
    port=7399,
    streamable_http_path="/mcp",
    json_response=True,      # 响应直接给 JSON，curl 好读
    stateless_http=True,     # 不要求会话 ID，客户端更好接
)


@mcp.tool()
async def echo(text: str) -> dict:
    """回显一段文本。用来验证 MCP 链路是否打通，不做任何业务。

    参数：text 任意字符串。
    返回：{"ok": true, "text": 原文, "length": 字数}
    """
    return {"ok": True, "text": text, "length": len(text)}


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
