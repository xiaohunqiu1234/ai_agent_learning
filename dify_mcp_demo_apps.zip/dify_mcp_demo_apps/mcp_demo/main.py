"""MCP 服务入口：读配置 → 注册工具 → 起服务。

main.py 只做这三件事，任何业务逻辑都不放这里。
新增业务域时，改 tools/__init__.py 一行即可，本文件不动。

启动（在 agent_learning 目录下）：
    python -m apps.mcp_demo.main                       # 默认 http://127.0.0.1:7301/mcp
    MCP_PORT=7302 python -m apps.mcp_demo.main         # 换端口
    MCP_TRANSPORT=sse python -m apps.mcp_demo.main     # 老客户端降级，端点 /sse

依赖：只用官方 MCP Python SDK（pip install mcp）。
"""

from __future__ import annotations

import os
import sys

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as exc:  # 给出可操作的提示，而不是裸 traceback
    raise SystemExit(
        "缺少 MCP 服务端依赖，请先安装：pip install 'mcp>=1.2'\n"
        f"（原始错误：{exc}）"
    ) from exc

from apps.mcp_demo.tools import register_all

PORT = int(os.getenv("MCP_PORT", "7301"))
HOST = os.getenv("MCP_HOST", "127.0.0.1")

TRANSPORT = os.getenv("MCP_TRANSPORT", "streamable-http").strip().lower()
if TRANSPORT not in ("streamable-http", "sse"):
    TRANSPORT = "streamable-http"

# 两个只影响"好不好调试"的开关：
#   MCP_JSON_RESPONSE=0  让响应走 SSE（MCP 默认），1 直接返回 JSON，curl 更好读
#   MCP_STATELESS=0      开启会话保持（默认无状态，Dify 更容易接）
JSON_RESPONSE = os.getenv("MCP_JSON_RESPONSE", "1") != "0"
STATELESS = os.getenv("MCP_STATELESS", "1") != "0"

mcp = FastMCP(
    "mcp-demo",
    instructions=(
        "示例 MCP 服务：同步工具 sync_call；"
        "异步工具 task_submit → task_status。换成自己的服务时先改工具描述。"
    ),
    host=HOST,
    port=PORT,
    streamable_http_path="/mcp",
    sse_path="/sse",
    json_response=JSON_RESPONSE,
    stateless_http=STATELESS,
    log_level=os.getenv("MCP_LOG_LEVEL", "INFO"),
)

# 注册中心：返回值只用于启动日志核对"到底挂了哪些模块"
REGISTERED = register_all(mcp)


def main() -> None:
    mcp.run(transport=TRANSPORT)


if __name__ == "__main__":
    path = "/sse" if TRANSPORT == "sse" else "/mcp"
    print(
        f"[mcp-demo] modules={REGISTERED} transport={TRANSPORT} "
        f"endpoint=http://{HOST}:{PORT}{path}",
        file=sys.stderr,
    )
    main()
