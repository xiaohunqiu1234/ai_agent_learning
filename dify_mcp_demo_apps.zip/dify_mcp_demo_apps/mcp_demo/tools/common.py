"""MCP 工具的公共层：把「调用一个 HTTP 接口」收敛成三种固定写法。

    ┌────────────────────┬──────────────────────┬────────────────────┐
    │ 上游形态            │ 用哪个函数            │ 典型场景            │
    ├────────────────────┼──────────────────────┼────────────────────┤
    │ 同步 JSON（POST）   │ post_json            │ 一次性返回的接口     │
    │ 只读查询（GET）     │ get_json / get_health│ 状态、列表、探活     │
    │ SSE + 后台任务      │ post_form_sse        │ 长耗时任务          │
    └────────────────────┴──────────────────────┴────────────────────┘

四条约定（每条都有代价，别省）：

1. 只用 httpx.AsyncClient。MCP 服务是单进程 asyncio，一个 requests 调用会让整个服务
   （包括健康检查）在调用期间全部无响应。
2. 上游 4xx/5xx、网络异常、非 JSON 一律转成 {"ok": false, "code", "message"}。
   抛异常时客户端只显示"调用失败"，看不到上游原始 message，等于没法排查。
3. 长文本必须截断。客户端节点变量有大小上限，几万字结果会把下游节点撑爆。
4. token / 密钥只透传：不落日志、不回显、不拼进 detail。
"""

from __future__ import annotations

import asyncio
import json
import os
import time

import httpx

# 上游可能很慢，默认给足，可用环境变量覆盖
DEFAULT_TIMEOUT = float(os.getenv("UPSTREAM_TIMEOUT", "60"))
# 返回给 LLM 的文本上限，超出部分截断并标注原长度
MAX_TEXT_CHARS = int(os.getenv("MCP_MAX_TEXT_CHARS", "12000"))

# 服务名 → (基址环境变量, 本机默认端口)
# 换成自己的服务时只改这张表；生产环境建议给变量加业务前缀，避免同机多服务冲突
_SERVICE_ENV: dict[str, tuple[str, int]] = {
    "sync": ("UPSTREAM_SYNC_BASE", 7300),
    "task": ("UPSTREAM_TASK_BASE", 7300),
}


# ───────────────────────────── 1. 信封：成功 / 失败 ─────────────────────────────

def ok(**payload) -> dict:
    """成功信封。

    统一带 ok=true，是为了让 LLM 和客户端的条件分支只判一个字段：
        if result.ok == true  → 正常分支
    否则每个工具成功时字段各不相同，工作流里要写一堆判断。
    """
    return {"ok": True, **payload}


def err(code: str, message: str, detail: str = "") -> dict:
    """失败信封。

    code     给机器判断（BAD_ARGS / UPSTREAM_4XX / SUBMIT_TIMEOUT …）
    message  给人看，直接进 LLM 上下文，要写清"怎么改"
    detail   给日志看，截断 2000 字，不要把整篇请求塞进来
    """
    out = {"ok": False, "code": code, "message": message}
    if detail:
        out["detail"] = detail[:2000]
    return out


def service_base(service: str) -> str:
    """上游基址：环境变量优先，其次本机默认端口。"""
    env_key, default_port = _SERVICE_ENV[service]
    base = (os.getenv(env_key) or "").strip()
    return (base or f"http://127.0.0.1:{default_port}").rstrip("/")


def truncate(text: str, limit: int | None = None) -> tuple[str, bool]:
    """按字符截断，返回 (文本, 是否被截断)。

    必须把 truncated 一起返回给 LLM，否则模型不知道"后面还有内容"，
    容易给出"信息不全"的错误结论。
    """
    limit = limit or MAX_TEXT_CHARS
    text = text or ""
    if len(text) <= limit:
        return text, False
    return f"{text[:limit]}\n…（已截断，原文 {len(text)} 字）", True


# ───────────────────────────── 2. 三种上游调用 ─────────────────────────────

async def post_json(
    url: str,
    payload: dict,
    headers: dict | None = None,
    timeout: float | None = None,
) -> tuple[dict | None, dict | None]:
    """POST JSON，返回 (body, error)——两者恰有一个为 None。

    用元组而不是抛异常，工具函数才能写成直线：
        data, error = await post_json(...)
        if error:
            return error
    """
    try:
        async with httpx.AsyncClient(
            timeout=timeout or DEFAULT_TIMEOUT,
            trust_env=False,  # 不读 HTTP_PROXY：直连上游，走代理只会多一跳
        ) as client:
            resp = await client.post(url, json=payload, headers=headers or {})
    except Exception as exc:  # noqa: BLE001 —— 网络/超时/DNS 全兜住
        return None, err("UPSTREAM_UNREACHABLE", f"{type(exc).__name__}: {exc}", url)

    if resp.status_code >= 400:
        detail = resp.text
        try:
            body = resp.json()
        except Exception:  # noqa: BLE001
            body = {}
        # 优先用上游自己的 message：它通常比"HTTP 401"更有信息量
        message = body.get("message") or f"上游返回 {resp.status_code}"
        code = "UPSTREAM_4XX" if resp.status_code < 500 else "UPSTREAM_5XX"
        return None, err(code, str(message), detail)

    try:
        return resp.json(), None
    except Exception:  # noqa: BLE001
        return None, err("UPSTREAM_BAD_JSON", "上游返回非 JSON", resp.text)


async def get_json(
    url: str,
    params: dict | None = None,
    timeout: float | None = None,
) -> tuple[dict | None, dict | None]:
    """GET JSON，语义同 post_json。只读查询都走这里。"""
    try:
        async with httpx.AsyncClient(
            timeout=timeout or DEFAULT_TIMEOUT, trust_env=False
        ) as client:
            resp = await client.get(url, params=params or {})
    except Exception as exc:  # noqa: BLE001
        return None, err("UPSTREAM_UNREACHABLE", f"{type(exc).__name__}: {exc}", url)

    if resp.status_code >= 400:
        detail = resp.text
        try:
            body = resp.json()
        except Exception:  # noqa: BLE001
            body = {}
        message = body.get("message") or f"上游返回 {resp.status_code}"
        code = "UPSTREAM_4XX" if resp.status_code < 500 else "UPSTREAM_5XX"
        return None, err(code, str(message), detail)

    try:
        return resp.json(), None
    except Exception:  # noqa: BLE001
        return None, err("UPSTREAM_BAD_JSON", "上游返回非 JSON", resp.text)


async def get_health(url: str, timeout: float = 8.0) -> dict:
    """健康检查：只关心通不通，永不抛异常。排障第一步永远先打这个。"""
    try:
        async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
            resp = await client.get(url)
        return {"ok": resp.status_code == 200, "status_code": resp.status_code}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


async def post_form_sse(
    url: str,
    form: dict,
    stop=None,
    probe=None,
    headers: dict | None = None,
    total_timeout: float | None = None,
    read_timeout: float = 90.0,
) -> dict:
    """POST 表单并按行消费 SSE，返回：

        {"task_id": str, "events": [...], "reason": str,
         "error": dict | None, "probe_calls": int}

    为什么不能当普通 JSON 调：上游是 StreamingResponse，任务 ID 只在响应头
    X-Task-Id，正文是持续到达的进度事件。必须先建立流、边读边决定"何时可以
    安全断开"，读完了才知道任务有没有真正提交。

    两个回调：
        stop(event) -> bool
            收到某个事件后立即停止。只能识别"终态"（completed/failed），
            识别不了"后台已接手"——那种信息根本不在事件里。
        probe(task_id, events, elapsed) -> bool | Awaitable[bool]
            侧信道：每 5 秒调一次，用 GET 查 meta 判断"是否已经可以安全断开"。
            返回 True 则断开；内部异常一律当作 False（宁可不提前断，也不能误断）。

    reason 取值：done / stop / probe / timeout / eof / http_error / error
    """
    task_id = ""
    events: list[dict] = []
    reason = "eof"
    started = time.monotonic()
    last_probe = 0.0
    probe_calls = 0
    http_error: dict | None = None

    # read_timeout 是"两次收到数据之间"的上限，不是总时长
    timeout = httpx.Timeout(read_timeout, connect=30.0, write=60.0, pool=30.0)

    async def _consume() -> None:
        nonlocal task_id, reason, last_probe, probe_calls, http_error
        async with httpx.AsyncClient(timeout=timeout, trust_env=False) as client:
            async with client.stream("POST", url, data=form, headers=headers or {}) as resp:
                # 任务 ID 在响应头，必须先拿，否则出错时连查都没法查
                task_id = resp.headers.get("x-task-id", "")
                if resp.status_code >= 400:
                    body = (await resp.aread()).decode("utf-8", "replace")
                    http_error = err(
                        "UPSTREAM_4XX" if resp.status_code < 500 else "UPSTREAM_5XX",
                        f"上游返回 {resp.status_code}",
                        body,
                    )
                    reason = "http_error"
                    return

                async for raw in resp.aiter_lines():
                    line = raw.strip()
                    # 空行是帧分隔符；":" 开头是心跳/注释行，两种都跳过
                    if not line or line.startswith(":"):
                        continue
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if payload in ("[DONE]", ""):
                        reason = "done"
                        break
                    try:
                        event = json.loads(payload)
                    except Exception:  # noqa: BLE001 —— 非 JSON 的 data 行直接跳过
                        continue
                    events.append(event)
                    if stop and stop(event):
                        reason = "stop"
                        break

                    # 每 5s 最多探测一次：既能及时发现"可断开"，又不会把上游打爆
                    now = time.monotonic()
                    if probe and now - last_probe >= 5.0:
                        last_probe = now
                        probe_calls += 1
                        try:
                            hit = probe(task_id, events, now - started)
                            if asyncio.iscoroutine(hit):
                                hit = await hit
                        except Exception:  # noqa: BLE001 —— 侧信道失败不影响主流程
                            hit = False
                        if hit:
                            reason = "probe"
                            break

    try:
        if total_timeout:
            await asyncio.wait_for(_consume(), timeout=total_timeout)
        else:
            await _consume()
    except asyncio.TimeoutError:
        # 超时后 httpx 的连接被取消，上游会认为客户端断开
        reason = "timeout"
    except Exception as exc:  # noqa: BLE001
        return {
            "task_id": task_id,
            "events": events,
            "reason": "error",
            "probe_calls": probe_calls,
            "error": err("UPSTREAM_UNREACHABLE", f"{type(exc).__name__}: {exc}", url),
        }

    return {
        "task_id": task_id,
        "events": events,
        "reason": reason,
        "probe_calls": probe_calls,
        "error": http_error,
    }
