"""范式二：SSE + 后台任务工具（异步接口的标准封装）。

四个上游事实必须先记住：

  1. 提交入口是 SSE：POST /api/tasks/upload 返回 StreamingResponse，
     任务 ID 只在响应头 X-Task-Id；表单支持 use_resource=true + resource_id，
     由上游自己按 ID 取资源 —— 所以 MCP 只传 ID，不传文件流
     （`tools/call` 的 arguments 是 JSON 对象，没有二进制类型；base64 可以塞进
     string，但模型产不出几 MB 的内容，徒增体积）。
  2. job_id 出现**之前**，解析都跑在当前请求进程内，此刻断开连接 → 生成器被取消
     → 任务根本没提交；job_id 出现**之后**断开，任务由后台引擎继续跑，是安全的。
  3. job_id 从不写进 SSE 事件，只在 GET /api/tasks/{id} 的 meta 里；
     SSE 里只有一条"任务已提交，任务ID: xxxxxxxx"（截断 12 位）。
  4. 结果文件 ID 只在流收尾阶段生成，因此 wait=false 拿不到。

结论：判断"能否安全断开"只能靠 side-channel 轮询 meta，也就是下面的 probe。
"""

from __future__ import annotations

from apps.mcp_demo.tools.common import (
    err,
    get_health,
    get_json,
    ok,
    post_form_sse,
    service_base,
    truncate,
)

SERVICE = "task"
BASE = service_base(SERVICE)
TASKS_URL = f"{BASE}/api/tasks"

# SSE 终态
_TERMINAL = ("completed", "failed", "timeout", "error")


def register(mcp) -> None:

    @mcp.tool()
    async def task_submit(
        resource_id: str,
        token: str,
        input: str = "",
        wait: bool = False,
        submit_timeout: int = 120,
        wait_timeout: int = 1800,
    ) -> dict:
        """提交一个异步任务。走 SSE 提交，长耗时任务用这个。

        参数：
            resource_id    资源 ID（必填，demo 里任意字符串即可）
            token          访问令牌（必填，demo 默认 demo-token）
            input          附加输入文本（可选）
            wait           false（默认）= 确认后台已接手（拿到 job_id）就返回；
                           true = 一直等到任务结束，可拿到结果文件 ID
            submit_timeout wait=false 时等待"后台接手"的上限秒数
                           （含解析/预处理，小资源 30s 内，大资源可能 600s）
            wait_timeout   wait=true 时整套流程的上限秒数

        返回（wait=false）：
            {"ok": true, "task_id", "job_id", "status", "detached": true,
             "last_progress", "probe_calls", "hint"}
        返回（wait=true）：
            {"ok": true, "task_id", "status": "completed", "item_count",
             "result_file_id", "output", "truncated"}

        注意：wait=false 若在 job_id 出现前超时，任务可能尚未提交 → SUBMIT_TIMEOUT。
        """
        # ── 本地校验：省掉一次必然失败的长调用 ──
        resource_id = (resource_id or "").strip()
        token = (token or "").strip()
        if not resource_id:
            return err("BAD_ARGS", "resource_id 必填：demo 可填 res-demo-001")
        if not token:
            return err("BAD_ARGS", "token 必填：demo 默认 demo-token")
        if wait and wait_timeout <= 0:
            return err("BAD_ARGS", "wait_timeout 必须大于 0")

        form = {
            "use_resource": "true",
            "resource_id": resource_id,
            "token": token,
            "input": input or "",
        }

        # ── probe：侧信道判断"后台是否已接手" ──
        async def _probe(task_id: str, _events, _elapsed) -> bool:
            """meta 里出现 job_id，说明后台已接手，此刻断开是安全的。

            三条硬约定：
              · 没 task_id 直接 False（不能瞎断）；
              · 查询失败返回 False（宁可不提前断，也不能误断）；
              · 调用频率由 post_form_sse 控制（5s 一次），别自己加循环。
            """
            if not task_id:
                return False
            body, error = await get_json(f"{TASKS_URL}/{task_id}", timeout=15.0)
            if error:
                return False
            return bool(((body or {}).get("data") or {}).get("job_id"))

        def _stop(event: dict) -> bool:
            """stop 只能识别终态，识别不了"已提交"。"""
            status = event.get("status")
            if wait:
                return status in _TERMINAL or bool(event.get("done"))
            return status in ("failed", "error")

        result = await post_form_sse(
            f"{TASKS_URL}/upload",
            form,
            stop=_stop,
            probe=None if wait else _probe,
            total_timeout=float(wait_timeout if wait else submit_timeout),
            # 解析阶段可能长时间没有事件，不能按常规 90s 判死
            read_timeout=300.0,
        )

        if result.get("error") and not result.get("task_id"):
            return result["error"]

        task_id = result.get("task_id") or ""
        reason = result.get("reason") or ""
        events = result.get("events") or []
        probe_calls = int(result.get("probe_calls") or 0)

        # 最后一条带 progress 的事件，出问题时能看出"卡在哪一步"
        last_progress = ""
        for event in reversed(events):
            if event.get("progress"):
                last_progress = str(event["progress"])
                break

        if not task_id:
            return err(
                "NO_TASK_ID",
                "上游未返回 X-Task-Id 响应头，无法追踪任务",
                f"reason={reason}",
            )

        # ── 断开后再查一次 meta：probe 与返回之间状态可能已经变化 ──
        meta: dict = {}
        body, error = await get_json(f"{TASKS_URL}/{task_id}", timeout=15.0)
        if not error:
            meta = (body or {}).get("data") or {}

        status = str(meta.get("status") or "")
        job_id = str(meta.get("job_id") or "")

        if status in ("failed", "error"):
            return err(
                "TASK_FAILED",
                str(meta.get("output") or "任务失败"),
                f"task_id={task_id} reason={reason}",
            )

        # 任务被上游判定取消：通常是上一轮连接断得太早
        if status == "cancelled":
            return err(
                "TASK_CANCELLED",
                "任务在提交给后台前被取消（连接断开过早），请重新发起",
                f"task_id={task_id} reason={reason} last_progress={last_progress}",
            )

        # 任务跑得比 probe 间隔还快时，wait=false 也能直接拿到完成态
        if status == "completed":
            output, truncated = truncate(str(meta.get("output") or ""))
            return ok(
                task_id=task_id,
                job_id=job_id,
                status="completed",
                detached=False,
                item_count=meta.get("item_count") or 0,
                result_file_id=meta.get("result_file_id") or [],
                result_file_url=meta.get("result_file_url") or "",
                download_url=meta.get("download_url") or "",
                output=output,
                truncated=truncated,
            )

        if wait:
            if status == "timeout" or reason == "timeout":
                return ok(
                    task_id=task_id,
                    job_id=job_id,
                    status="timeout",
                    last_progress=last_progress,
                    resumable=bool(job_id),
                    hint="未在 wait_timeout 内结束，用 task_status 继续轮询",
                )
            return ok(
                task_id=task_id,
                job_id=job_id,
                status=status or "unknown",
                last_progress=last_progress,
                hint="流已结束但没读到 completed，请用 task_status 复核",
            )

        if job_id:
            return ok(
                task_id=task_id,
                job_id=job_id,
                status=status or "processing",
                detached=True,
                probe_calls=probe_calls,
                last_progress=last_progress,
                hint="已确认后台接手，用 task_status(task_id) 轮询；"
                     "本模式不生成结果文件 ID，需要文件请用 wait=true 重新发起",
            )

        # 到这里说明：流结束了，但 job_id 仍为空 —— 任务很可能没提交
        return err(
            "SUBMIT_TIMEOUT" if reason == "timeout" else "SUBMIT_INCOMPLETE",
            "未确认后台已接手（job_id 为空），任务可能未提交",
            f"task_id={task_id} reason={reason} last_progress={last_progress}；"
            "解析在上游进程内，过早断开会导致任务取消",
        )

    @mcp.tool()
    async def task_status(task_id: str) -> dict:
        """查询异步任务状态（只读）。

        status 取值：uploaded / processing / completed / failed / cancelled / timeout。
        status=completed 时才有 output / result_file_id。
        """
        task_id = (task_id or "").strip()
        if not task_id:
            return err("BAD_ARGS", "task_id 必填")
        body, error = await get_json(f"{TASKS_URL}/{task_id}", timeout=20.0)
        if error:
            # 把上游 404 翻译成业务语义，LLM 才知道"ID 写错了"
            if error.get("code") == "UPSTREAM_4XX":
                return err("NOT_FOUND", f"任务不存在：{task_id}", error.get("detail", ""))
            return error

        data = (body or {}).get("data") or {}
        output, truncated = truncate(str(data.get("output") or ""))
        return ok(
            task_id=task_id,
            status=data.get("status") or "",
            job_id=data.get("job_id") or "",
            item_count=data.get("item_count") or 0,
            result_file_id=data.get("result_file_id") or [],
            result_file_url=data.get("result_file_url") or "",
            download_url=data.get("download_url") or "",
            output=output,
            truncated=truncated,
            live=(body or {}).get("live"),
            resumable=bool((body or {}).get("resumable")),
            hint=(body or {}).get("hint") or "",
        )

    @mcp.tool()
    async def task_list(limit: int = 10) -> dict:
        """列出最近的异步任务（只读，按创建时间倒序）。"""
        body, error = await get_json(TASKS_URL, timeout=20.0)
        if error:
            return error
        rows = (body or {}).get("data") or []
        try:
            limit = max(1, min(int(limit or 10), 50))
        except (TypeError, ValueError):
            limit = 10
        return ok(total=len(rows), items=rows[:limit])

    @mcp.tool()
    async def task_health() -> dict:
        """检查异步服务是否可用（连同后台任务引擎状态）。"""
        result = await get_health(f"{TASKS_URL}/health", timeout=15.0)
        return ok(service=SERVICE, base=BASE, **result)
