"""范式一：同步 JSON 工具（最小可改造模板）。

选它做第一个工具的原因：
    · 入参全 JSON，没有文件流；
    · 同步返回，没有 job_id 轮询；
    · 返回结构固定，最容易端到端验证。

上游契约（由 sample_upstream 提供）：
    POST /api/sync
    {"token", "input"} → 200 {"code":200,"data":{"output","length"}}
                       → 400/401/404 {"code","message"}
"""

from __future__ import annotations

from apps.mcp_demo.tools.common import (
    err,
    get_health,
    ok,
    post_json,
    service_base,
    truncate,
)

_PATH = "/api/sync"
_HEALTH_PATH = "/api/health"

# 本地输入上限：超过就拒绝，避免把巨大的字符串塞进上游
MAX_INPUT_CHARS = 20000


def register(mcp) -> None:
    """把一个业务域的工具挂到 mcp 实例上。

    约定：每个业务模块只暴露 register(mcp) 一个入口，
    这样 tools/__init__.py 只需要维护一张模块清单，main.py 永远不用改。
    """

    @mcp.tool()
    async def sync_call(input: str, token: str) -> dict:
        """调用同步接口，一次拿到处理结果。适合耗时几十秒内的接口。

        参数：
            input  要处理的文本（必填，最多 20000 字）
            token  访问令牌（必填，demo 默认 demo-token）

        返回：
            {"ok": true, "output": "……", "length": 128, "truncated": false}
            {"ok": false, "code": "BAD_ARGS|UPSTREAM_4XX|...", "message": "……"}

        注意：上游没有批量接口，一次只能处理一条。
        """
        # ── 第 1 步：本地校验。能本地判掉的错误绝不打上游 ──
        input = (input or "").strip()
        token = (token or "").strip()
        if not input:
            return err("BAD_ARGS", "input 必填：随便传一段文本即可，如 hello")
        if not token:
            return err("BAD_ARGS", "token 必填：demo 默认 demo-token")
        if len(input) > MAX_INPUT_CHARS:
            return err(
                "BAD_ARGS",
                f"input 过长（{len(input)} 字），上限 {MAX_INPUT_CHARS} 字",
            )

        # ── 第 2 步：组装上游入参（命名风格转换只在这里做一次） ──
        payload = {"token": token, "input": input}

        # ── 第 3 步：调用。error 非空就直接当工具返回值 ──
        data, error = await post_json(service_base("sync") + _PATH, payload)
        if error:
            return error

        # ── 第 4 步：校验业务码（有的上游 HTTP 200 但 body.code=500） ──
        if data.get("code") not in (200, None):
            return err(
                "UPSTREAM_REJECTED",
                str(data.get("message") or "上游返回非成功状态"),
                str(data)[:800],
            )

        body = data.get("data") or {}
        output, truncated = truncate(str(body.get("output") or ""))
        if not output:
            # 空结果必须当失败：返回空字符串会让 LLM 以为"没有内容"
            return err("EMPTY_RESULT", "上游返回空结果", str(data)[:800])

        return ok(
            output=output,
            length=body.get("length") or len(output),
            truncated=truncated,
        )

    @mcp.tool()
    async def sync_health() -> dict:
        """检查同步接口是否可用（排障第一步，无参数）。"""
        result = await get_health(service_base("sync") + _HEALTH_PATH)
        return ok(service="sync", base=service_base("sync"), **result)
