"""工具层：每个业务域一个模块，只暴露 register(mcp)。

新增一个业务域，只需要：
    1. 新建 tools/<domain>.py，写 register(mcp)
    2. 在下面的 _MODULES 里加一项
main.py 永远不用改。
"""

from apps.mcp_demo.tools import sync_api, task_api

# 顺序 = tools/list 里的工具顺序
_MODULES = (sync_api, task_api)


def register_all(mcp) -> list[str]:
    """按顺序注册所有模块，返回模块名列表（只用于启动日志核对）。"""
    for mod in _MODULES:
        mod.register(mcp)
    return [mod.__name__.rsplit(".", 1)[-1] for mod in _MODULES]


__all__ = ["register_all"]
