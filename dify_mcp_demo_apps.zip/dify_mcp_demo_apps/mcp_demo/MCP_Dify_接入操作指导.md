# 从你的服务到 Dify MCP：落地路线

> 适用：手里已经有一个 HTTP 接口，要把它变成 Dify 里能被 LLM 调用的工具。
> 本文不含任何业务语义，只讲"怎么把你的接口包进来"。
> 配套示例：`agent_learning/apps/mcp_demo/`，一条命令可跑通，用来对照着改。

---

## 0. 先搞懂：Dify 封装 MCP 到底在做什么（30 分钟）

### 0.1 这件事是在做什么

Dify 是个流程编排器：它把一句话的活儿拆成节点，让模型在节点里挑工具、填参数、总结结果。
但模型和 Dify 都没法直接连你的业务系统——它们需要一份"工具目录"，里面每样工具都带着
说明书：叫什么、干什么用、要填哪些参数。

MCP 就是这份说明书的格式标准。所谓"给 Dify 封装 MCP"，说白了就是在你的业务接口
外面加一层"带说明书的传话人"：

```
你的业务接口（会干活，但模型看不懂怎么调）
      ↓ 包一层
MCP 服务（把接口翻译成带说明书的工具）
      ↓ 标准协议（工具清单 / 参数表 / 结果）
Dify（模型在工具面板里挑工具、填参数、调用）
```

这一层实际包掉了五件事，每件都能在后面找到对应章节：

| 它包掉什么 | 没有它会怎样 | 在哪章 |
|---|---|---|
| 工具说明书：名称、用途、参数表 | 模型不知道有哪些能力、参数怎么填 | 2、4 |
| 参数检查与鉴权透传 | 错参数直接打到业务系统，白耗一次调用 | 3、4 |
| 结果统一信封（成功/失败一个格式） | 每个接口字段都不一样，工作流没法统一判断 | 3 |
| 异步任务的断连与轮询细节 | 长任务要么把连接挂死，要么断开就把任务弄丢 | 5 |
| 超时、超长文本等边界处理 | Dify 节点被大结果撑爆，慢接口被误判失败 | 3 |

一句话记住：**MCP 层不干活，它负责让模型"会用"你的接口，并且怎么都不出错。**

### 0.2 整体是怎么做的

落地时只拆四个构件，各管一摊：

| 构件 | 文件 | 干什么 |
|---|---|---|
| 入口 | `main.py` | 起服务、定端口和协议参数；启动时把工具装上 |
| 登记表 | `tools/__init__.py` | 一张清单：有哪些业务模块，按顺序装上 |
| 业务模块 | `tools/sync_api.py`、`tools/task_api.py` | 一个业务域一个文件：写工具说明 + 检查参数 + 映射字段 |
| 公共层 | `tools/common.py` | 大家共用的跑腿和售后：发请求、翻译错误、截断、套信封 |

信息流只有两个阶段，理解这两条就够用了：

```
注册期（服务启动，只走一次）
    main.py → 登记表 → 各模块的 register() → 工具挂到服务上

调用期（每次请求都走一遍）
    Dify → main.py（按名字找函数、把参数填进去）
         → 业务模块（检查参数、拼上游字段）
         → common.py（发请求、翻译错误、套信封）
         → 你的上游 → 原路返回给 Dify
```

接着往下读的顺序是：代码目录怎么搭（0.3）→ 调用链细节（0.4）→
你的接口属于哪种模式（0.5 起）→ 先跑起来（0.9）。

### 0.3 代码目录怎么构建

**目录里每个文件是干嘛的：**

```
apps/mcp_demo/
├── main.py              服务总开关：起名、装工具、开门营业（对应 6.2）
├── tools/               真正的"工具车间"
│   ├── common.py        公共层：统一信封、超时、截断、发请求（第 3 章，谁都不许业务味）
│   ├── sync_api.py      同步工具模板（形态 1，第 4 章）
│   ├── task_api.py      异步工具模板（形态 3/4，第 5 章）
│   └── __init__.py      工具登记表：新工具在这里加一行（6.1）
├── sample_upstream.py   示例上游：假装是"你的业务服务"，替换成真上游后整个删掉
├── minimal_example.py   30 行最小服务：只验证协议通不通，与业务无关（第 2 章）
├── demo_client.py       演练客户端：连上 MCP 逐个调工具（8 步自测在这里）
├── run_demo.py          一键起服务 + 跑演练 + 收摊（0.9 的第 2 步就是它）
├── requirements.txt     依赖清单
└── MCP_Dify_接入操作指导.md   本文档
```

**一次调用经过谁的手（拿同步工具 `sync_call` 举例）：**

```
Dify / demo_client          "调 sync_call(input=..., token=...)"
    ↓ HTTP (JSON-RPC)
main.py                     收下请求，按登记表找到工具
    ↓ 直接函数调用
tools/sync_api.py           检查参数 → 拼请求
    ↓
tools/common.py             post_json 发给上游，拿到结果套上统一信封
    ↓ HTTP
sample_upstream.py          真正干活的"业务服务"，返回结果
    ↓ 原路返回
Dify 收到一段 JSON 字符串    {"ok": true, "output": ...}
```

异步工具多一步：`task_api.py` 还会拿 task_id 反复查上游（`probe`/`task_status`），
但走的仍是 `common.py` 的那几个函数——**业务模块自己不发请求，都托公共层代办**。

**三条分层规矩（改代码时别破坏）：**

| 规矩 | 为什么 |
|---|---|
| `common.py` 里不写业务判断 | 它是所有工具共用的地基；塞进业务，下次换服务就得动地基 |
| 业务模块只暴露 `register(mcp)`，装饰器写在它内部 | `main.py` 和登记表才能永远不用改 |
| 工具函数不直接 `httpx.post`，一律走 `post_json` / `get_json` / `post_form_sse` | 错误翻译、超时、信封格式只在公共层做一次 |

**所以加一个新工具，总共只动两个文件：**

1. 新建 `tools/<你的域>.py`（抄第 4 章或第 5 章模板，改路径和字段）；
2. 在 `tools/__init__.py` 的登记表里加一行。

`main.py` 一行不用改，重启服务，`tools/list` 里就有新工具了。新代码怎么接进调用链，见 0.4。

### 0.4 调用关系链：新代码从哪里接入

上面画的是"一次调用"的链路，还有一条容易被忽略的链——**启动时的注册链**。
新代码必须接进这两条链才算装上了。

**链一：启动时的注册链（服务每次启动只走一遍）**

```python
# tools/__init__.py
_MODULES = (sync_api, task_api)          # ← 新模块加在这里

def register_all(mcp) -> list[str]:
    for mod in _MODULES:
        mod.register(mcp)                # ← 逐个调每个模块的 register
    return [mod.__name__.rsplit(".", 1)[-1] for mod in _MODULES]
```

```python
# main.py
REGISTERED = register_all(mcp)           # ← import 时执行一次
```

串起来：

```
main.py（import 时）
  → tools/__init__.py: register_all(mcp)
      → 逐个调 sync_api.register(mcp)、task_api.register(mcp)……
          → 模块内的 @mcp.tool() 把函数挂到服务上
```

`register(mcp)` 之所以存在：`@mcp.tool()` 装饰器必须能拿到 `mcp` 实例才能挂函数，
所以每个模块把它包在自己的 `register` 里，import 时什么都不做，
等 `register_all` 来调。启动日志 `modules=[...]` 打的就是这条链的核对结果。

**链二：依赖方向只有一条线（谁 import 谁）**

```
main.py ──▶ tools/__init__.py ──▶ sync_api / task_api ──▶ common.py ──▶ 上游
   ▲                                     │
   └── 不 import 业务模块，只拿 register_all ──┘
```

三条禁止逆行，破了分层就塌：

- `main.py` 不 import 具体业务模块（只 import `register_all`）；
- `common.py` 不 import 任何业务模块——它连"上游长什么样"都不知道；
- 业务模块之间互不调用。

全部箭头都指向 `common.py`，所以换上游时只有它（多数时候只有那张地址表）可能要改。

**新增模块的三个接入点**

| 接入点 | 干什么 | 对应哪条链 |
|---|---|---|
| import `common` 的函数（不自己写 `httpx`） | 接入运行链的"发请求"环节 | 链二 |
| 写 `register(mcp)`，工具函数定义在其内部 | 接入注册链的唯一入口 | 链一 |
| `_MODULES` 元组加一项 | 让注册链知道你存在 | 链一 |

三处做完，注册链自动把工具挂上服务，调用链自动把 Dify 的请求送进你的函数——
中间的参数填充、结果打包都是 FastMCP 现成的，不用碰。

**一个 import 期的坑**

`task_api.py` 在模块顶层就调了 `service_base("task")` 把基址定死：

```python
SERVICE = "task"
BASE = service_base(SERVICE)      # ← import 时就取好了
TASKS_URL = f"{BASE}/api/tasks"
```

这样写的含义是：**改环境变量必须重启服务才生效**。新模块照抄可以（行为可预期），
也可以把 `service_base()` 挪进工具函数内部每次现取——二选一，别混着来，
否则"改了配置没生效"这种问题会查半天。

### 0.5 深入：四种接口形态

架构和代码结构清楚了，接下来是真正决定怎么写代码的问题：**你的上游属于哪一种？**
答案由两件事决定——结果什么时候产生、连接断了会怎样。

| # | 形态 | 结果何时产生 | 断开连接的后果 | MCP 侧真正的难点 | 模板 |
|---|---|---|---|---|---|
| 1 | **同步请求-响应** | 响应返回时 | 无副作用，可安全重试 | 别阻塞事件循环、别被 Dify 超时掐断 | `sync_api.py` |
| 2 | **提交-轮询**（202 + 状态查询） | 另一个接口里 | 无副作用，用 ID 续查 | 拆成 2 个工具 + 告诉模型去轮询 | `sync_api.py` + 7.4 场景 A |
| 3 | **SSE + 后台任务** | 后台引擎里 | **断太早 = 任务取消** | 判断"何时能安全断"（probe） | `task_api.py` |
| 4 | **纯流式 SSE**（边算边吐，无后台任务） | 流结束前一刻 | 结果丢弃，需重来 | 读完才算拿到结果，没有"提前返回" | 5.11 的改法 |

后三种（都带"异步"味道）最容易混。一句区分：

```
看结果从哪来
├─ 就在这次响应体里，且响应是一次性的 ──────▶ 形态 1 同步
├─ 在另一个接口里，这次只给你一个 ID ──────▶ 形态 2 提交-轮询
└─ 在这条连接上持续吐出来
   ├─ 断开后任务还在跑（能查到状态）────────▶ 形态 3 SSE + 后台任务
   └─ 断开就没了（查不到任何状态）──────────▶ 形态 4 纯流式
```

### 0.6 为什么要区分：五个差异，每个都改代码

**① 失败模式不同 → 重试语义不同。**
同步失败 = 这次调用没成功，重试安全；
提交-轮询失败 = 任务可能已经建了，重试可能产生两个任务（要用幂等键）；
SSE 断在提交前 = 任务被取消，必须重发；断在提交后 = 任务还在跑，**不能重发**。

**② 能给 LLM 的东西不同。**
形态 1 能一次给完整结果；形态 2 只能给 `task_id` + 一句"用 xx 查"；
形态 3 提前返回时只有进度，结果文件要到收尾才生成。工具返回结构完全不同。

**③ 超时边界不同。**
形态 1 撞的是 Dify 的 30s/300s；形态 2 撞的是"轮询次数 × 间隔"；
形态 3 撞的是"两次事件之间的间隔"（解析期可能几分钟没有事件）。

**④ 实现量级差一个数量级。**
形态 1 约 40 行；形态 2 约 60 行（两个工具）；形态 3 约 200 行（`post_form_sse`
+ `probe` + 状态机）。把形态 1/2 当成 3 来写，等于白写一百多行。

**⑤ 判断错一次，返工一天。**
所以第 1 章不是"填表走流程"，而是把这四种分清。

### 0.7 误判的后果

| 实际形态 | 你以为是 | 会发生什么 | 症状 |
|---|---|---|---|
| 形态 1 | 形态 2 | 多拆一个查询工具、多一轮轮询 | 白写 60 行，还多一次往返 |
| 形态 2 | 形态 1 | 在工具里死等结果 | Dify 节点超时，任务已建但没人查 |
| 形态 3 | 形态 1 | `await client.post()` 等到流结束 | 卡几分钟，提前返回做不到 |
| 形态 3 | 形态 2 | 用普通 POST 提交 | 拿不到 `X-Task-Id`，也没有进度 |
| 形态 4 | 形态 3 | `probe` 永远查不到 job_id | 每次等满 `submit_timeout` |
| 形态 2 | 形态 3 | 去读 SSE 事件 | `events` 为空，全靠 probe，超时 |

### 0.8 路线图

```
你的接口
├─ 形态 1 同步 JSON ────────────▶ 第 4 章：改 sync_api.py
├─ 形态 2 提交-轮询 ────────────▶ 第 4 章 + 7.4 场景 A（不写 SSE）
├─ 形态 3 SSE + 后台任务 ───────▶ 第 5 章：改 task_api.py（含 probe/状态机）
└─ 形态 4 纯流式 SSE ───────────▶ 第 4 章 + 5.11（去掉 probe，读到 done 才算结果）
             ↓
      公共层（第 3 章，一次写好，长期复用）
             ↓
      装配 + 自测（第 6 章）
             ↓
      替换成你的服务（第 7 章，主菜）
             ↓
      接入 Dify（第 8 章）
```

判定方法（`curl -i` 看 `Content-Type`、看是否立刻回 ID、断开后能否查到状态）
放在 1.2，四条命令照抄即可。

| 步骤 | 产出 | 验收 | 耗时 | 章节 |
|---|---|---|---|---|
| 1 盘点 | 一张《接口盘点表》 | 能手工 curl 出上游每种返回 | 30 min | 1 |
| 2 协议 | 30 行最小 MCP 服务 | `tools/list` 有 Schema，`tools/call` 返回 JSON | 20 min | 2 |
| 3 公共层 | 信封/超时/截断/SSE 四个函数 | 4xx、断网、超长文本都返回信封 | 1 h | 3 |
| 4 同步工具 | 一个能用的工具 | 成功 / 参数错 / token 错三种返回都对 | 1.5 h | 4 |
| 5 异步工具 | 提交+查询+列表 | 能主动断开，任务继续跑；断太早能识别 | 2~3 h | 5 |
| 6 装配 | `main.py` 起服务 | 启动日志打印模块清单 | 30 min | 6 |
| 7 替换 | 路径、字段、鉴权全换成你的 | 回归六条全过 | 0.5~2 天 | 7 |
| 8 Dify | 工作流里能调用 | 「获取工具」成功，跑通一次 | 1 h | 8 |

只做同步工具：第 1~4、6、8 章，半天可完成。
带异步/SSE：第 5 章会占一半时间，这是唯一"不看时序就会写错"的部分。

### 0.9 现在把 demo 跑起来（10 分钟）

看完全貌，先什么都不改地把示例完整跑一遍——环境有没有坑、每一步长什么样，
跑一次全知道。前置只要两样：Python 3.10 以上（`python3 --version` 确认）、pip 能装包。

**第 1 步：装依赖**（在仓库根目录下执行）

```bash
cd /Users/cqj/Documents/agent_learning_orginal/agent_learning
python3 -m pip install -r apps/mcp_demo/requirements.txt
```

四个包：`mcp`（官方 SDK）、`httpx`（发请求）、`fastapi` 和 `uvicorn`
（只给示例上游用，换成真上游后可以删）。

**第 2 步：一键跑通**

```bash
python3 -m apps.mcp_demo.run_demo
```

它会自动把示例上游（7300）和 MCP 服务（7301）都开起来，按顺序跑完 8 步自测
（列工具清单、健康检查、同步调用、参数校验、上游 4xx、异步断开+轮询、
等到底、断太早），结束自动收摊。8 步全部通过、没有任何一步报错，环境就绪。

想让服务一直开着给 Dify 用，加 `--keep`（Ctrl+C 手动收摊）：

```bash
python3 -m apps.mcp_demo.run_demo --keep
```

**第 3 步（可选）：分开起，自己 curl 玩**

想看清楚"两个服务各自在干嘛"，就开三个终端：

```bash
# 终端 1：示例上游（本来的业务服务扮演者）
python3 -m uvicorn apps.mcp_demo.sample_upstream:app --port 7300

# 终端 2：MCP 服务（要封装出来的那一层）
MCP_PORT=7301 python3 -u -m apps.mcp_demo.main

# 终端 3：假装自己是 Dify，问一句"你有哪些工具"
curl -sS -X POST http://127.0.0.1:7301/mcp \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'
```

终端 2 启动时会打印一行模块清单，看到它就说明注册成功：

```text
[mcp-demo] modules=['sync_api', 'task_api'] transport=streamable-http endpoint=http://127.0.0.1:7301/mcp
```

三个最常见的报错：

| 报错 | 原因 | 处理 |
|---|---|---|
| `No module named 'apps'` | 不在仓库根目录 | `cd agent_learning` 再跑 |
| `No module named 'mcp'` / `'httpx'` | 依赖没装上 | 重跑第 1 步 |
| `address already in use` | 上次的进程还占着端口 | `pkill -f apps.mcp_demo` 后重跑 |

---

## 1. 先盘点：你的接口是哪一种（30 分钟）

### 1.1 填这张表

| 项 | 你的服务 | demo 示例 |
|---|---|---|
| 服务名 / 用途 | ? | 示例上游 |
| 基址 | ? | `http://127.0.0.1:7300` |
| 鉴权方式 | ? | JSON/form 里的 `token=demo-token` |
| 调用形态 | 形态 1/2/3/4（见 0.5） | 形态 1 + 形态 3 |
| 任务 ID 在哪 | header / body / 没有 | 响应头 `X-Task-Id` |
| 单次耗时 | ? | 同步 0.8s，异步 10s |
| 结果大小 | ? | 几十字 |
| 是否要求先上传拿 ID | ? | 是（`resource_id`） |

填不出来，说明还没读出上游真实行为，别急着写封装。

### 1.2 判定：四条命令，不靠猜

先别急着写代码——这四条命令其实是在问上游四个问题：你是不是流式的？
回 ID 快不快？有没有地方能查进度？我不听了你会怎么样？
四个答案一对，就知道该用哪套写法。

```bash
# ① 是不是事件流（形态 3/4）
curl -i -sS -X POST "$URL" -d '...' | head -20
#    Content-Type: text/event-stream → 是

# ② 是否"毫秒级就回 ID"（形态 2/3）还是"等几秒给结果"（形态 1）
#    看总耗时和响应体：立刻返回 {"id": ...} 就是提交型

# ③ 有没有第二个查询接口（形态 2/3 必有，形态 1/4 没有）
curl -sS "$BASE/<资源>/$ID"

# ④ 断开测试：只读 2 秒就断，然后立刻回查（区分 3 和 4）
curl -sS -D - -o /dev/null --max-time 2 -X POST "$URL" ... | grep -i x-task-id
curl -sS "$BASE/<资源>/$ID"
#    能查到 cancelled/processing → 形态 3（有后台任务）
#    查不到任何状态           → 形态 4（断开即丢弃）
```

| ① 事件流 | ② 立刻回 ID | ③ 有查询接口 | ④ 断开后能查到 | 判定 |
|---|---|---|---|---|
| 否 | 否 | 否 | — | 形态 1 同步 |
| 否 | 是 | 是 | 能（无副作用） | 形态 2 提交-轮询 |
| 是 | 是 | 是 | 能（取消或继续跑） | 形态 3 SSE + 后台任务 |
| 是 | 否 | 否 | 查不到 | 形态 4 纯流式 |

另外两条独立规则：

- 入参含 `files=` → 不传文件，改传资源 ID（1.5）；
- 单次耗时 > 60s 的同步接口 → 超时调大，并优先推动上游提供异步接口。

> 上面说的"任务 ID"是能力描述，不是字段名。MCP 对参数名没有任何命名规范：
> 叫 `task_id`、`jobId`、`request_id`、`order_no` 都行，唯一要求是**工具签名、
> docstring、映射到上游的那一行三处一致**。本文统一写 `task_id`，只是因为示例上游
> 的路径参数也叫这个名字，少一次心智转换。

### 1.3 一个接口拆成几个工具

| 上游能力 | 拆法 | 理由 |
|---|---|---|
| 纯查询、参数少 | 1 接口 = 1 工具 | 模型一次调完 |
| 提交 + 查状态 | 拆 2 个 | 提交必须快速返回，否则 Dify 超时 |
| 提交 + 查状态 + 列表 | 拆 3 个 | 列表用于"我刚提交的那个" |
| 健康检查 | 单独 1 个 | 排障第一步 |
| 10 个相似接口 | 合并成"按 type 分发" | 工具太多模型选不准 |

反例：`do_everything(action, payload)`。参数是自由 JSON，Schema 等于没有，
模型只能瞎填，错误率比多几个工具高得多。

### 1.4 不该封装的东西

- **文件二进制**：`tools/call` 的 `arguments` 是 JSON 对象（`dict[str, Any]`），
  **没有二进制类型**。把 bytes 转成 base64 塞进 `string` 参数在协议上是合法的，
  但模型只能生成文本，几 MB 的 base64 既进不了上下文，也会撞上客户端/网关的 body 上限。
  结论是"别传二进制"，不是"协议不支持"——具体取舍见 1.5。
- **超大结果**：几十万字不要整段返回，截断 + 给下载链接 + 摘要。
- **前端专用参数**：`page`、`sortBy`、UI 文案对 LLM 无意义。
- **跨多个接口的编排**：编排属于 Dify 工作流，不属于单个工具。

### 1.5 示例契约（照这个粒度填你的表）

| 用途 | 方法 + 路径 | 入参 | 返回 |
|---|---|---|---|
| 同步处理 | `POST /api/sync` | JSON：`token, input` | `200 {code,data:{output,length}}`；`400/401/404 {code,message}` |
| 提交任务 | `POST /api/tasks/upload` | form：`use_resource=true, resource_id, token, input` | 响应头 `X-Task-Id` + SSE 流 |
| 查任务 | `GET /api/tasks/{id}` | — | `{code,data:{status,job_id,output,item_count,result_file_id},live,resumable,hint}` |
| 任务列表 | `GET /api/tasks` | — | `{code,data:[...]}` |
| 健康检查 | `GET /api/health`、`GET /api/tasks/health` | — | `{status,service,sample}` |

文件类入参有四种走法，按推荐程度排序：

| 方式 | 协议上可行 | 主要代价 | 建议 |
|---|---|---|---|
| 传业务侧资源 ID（先上传） | 是 | 业务系统要有上传入口 | **默认方案** |
| 传可访问 URL | 是 | SSRF、鉴权、链接时效 | 上游能直连时可用 |
| base64 塞进 `string` 参数 | 是（JSON 合法） | 体积 +33%、模型产不出、body 上限 | 仅工具间内部调用 |
| MCP Resource / `resource_link` | 是，但方向相反 | 资源由 server 暴露给 client，需客户端消费 | 自研客户端才考虑 |

推荐链路：

```
用户 → 业务系统上传文件 → 拿到 resource_id → LLM 调工具(resource_id)
                                          → 上游自己用 ID 取文件
```

返回方向宽松得多：`CallToolResult.content` 支持 `text` / `image` / `audio`（后两者
是 base64 数据）以及 `resource_link`（大文件只给 URI）。但客户端普遍只把 `text`
交给模型，所以"返回文件"仍建议给下载链接，而不是 base64。

---

## 2. 起一个最小 MCP 服务（20 分钟）

先确认「客户端 ↔ MCP ↔ JSON-RPC」通了，再谈业务。

### 2.1 代码（`apps/mcp_demo/minimal_example.py`）

下面就是 `apps/mcp_demo/minimal_example.py` 的全部内容——一个"只会复读"的最小服务：
开个门（7399 端口），挂一个 echo 工具，你发什么它原样回什么。
先证明「客户端 ↔ MCP」这条路是通的，再谈业务。

```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "minimal-demo",
    host="127.0.0.1",
    port=7399,
    streamable_http_path="/mcp",
    json_response=True,      # 响应直接给 JSON，curl 好读
    stateless_http=True,     # 不要求会话 ID，客户端更好接
)


@mcp.tool()
async def echo(text: str) -> dict:
    """回显一段文本。用来验证 MCP 链路是否打通，不做任何业务。

    参数：text 任意字符串。
    返回：{"ok": true, "text": 原文, "length": 字数}
    """
    return {"ok": True, "text": text, "length": len(text)}


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
```

### 2.2 跑起来验两条

跑法很简单：终端 A 把服务开起来；终端 B 假装自己是 Dify，问了一句
"你都有哪些工具？"（tools/list）。

```bash
# 终端 A
python3 -m apps.mcp_demo.minimal_example

# 终端 B
curl -sS -X POST http://127.0.0.1:7399/mcp \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'
```

期望返回（节选）——这就是服务的"自我介绍"：我叫 echo、我是干嘛的（description）、
找我办事要填什么参数（inputSchema）。模型就是靠这三样决定用不用这个工具。

```json
{"result":{"tools":[{"name":"echo",
 "description":"回显一段文本。…… 返回：{\"ok\": true, \"text\": 原文, \"length\": 字数}\n",
 "inputSchema":{"properties":{"text":{"title":"Text","type":"string"}},
                "required":["text"],"type":"object"}}]}}
```

这条 JSON 说明三件事：函数名 → `name`（模型选工具）、docstring → `description`
（模型判断该不该用）、类型标注 → `inputSchema`（模型填参数）。

### 2.3 三种误判

| 现象 | 含义 | 处理 |
|---|---|---|
| `GET /mcp` 返回 405 | 正常，端点只收 POST | 不用管 |
| 响应是 `event: message` 流 | `json_response` 没开 | 设 `MCP_JSON_RESPONSE=1` |
| `tools` 是空数组 | 装饰器没生效 | 确认 `@mcp.tool()` 在 `run()` 之前执行 |

---

## 3. 公共层：这四个函数一次写好（1 小时）

### 3.1 先写它的理由

三个坑，每个工具都会踩一遍：

| 坑 | 后果 |
|---|---|
| 用同步 HTTP 客户端 | 一个慢请求卡死整个 asyncio 进程，健康检查也超时 |
| 直接抛异常 | 客户端只显示"调用失败"，上游 message 丢失，模型无法自愈 |
| 不截断长文本 | 下游节点变量有上限，大结果直接撑爆 |

### 3.2 信封：成功与失败同构

这两个小函数都在 `apps/mcp_demo/tools/common.py` 里，作用是给所有工具定一个
"回话的统一格式"：成功就 `ok=true` 带结果，
失败就 `ok=false` 带原因。格式统一了，Dify 里的判断逻辑才只需要一种写法。

```python
def ok(**payload) -> dict:
    return {"ok": True, **payload}


def err(code: str, message: str, detail: str = "") -> dict:
    out = {"ok": False, "code": code, "message": message}
    if detail:
        out["detail"] = detail[:2000]
    return out
```

| 字段 | 给谁看 | 要求 | 例子 |
|---|---|---|---|
| `ok` | 条件分支 | 永远存在 | `true` / `false` |
| `code` | 机器判断 | 固定枚举 | `BAD_ARGS`、`UPSTREAM_4XX`、`TASK_CANCELLED` |
| `message` | LLM 与用户 | 写"怎么改" | `input 必填：随便传一段文本即可` |
| `detail` | 人与日志 | 上游原文，截断 2000 字 | `reason=timeout` |

**禁止抛异常**：MCP 的 `isError` 只是布尔值，客户端通常只显示"调用失败"。
上游那句 `token 无效或已过期` 留在服务端日志里，模型看不到也就没法纠正。
本项目约定：失败也返回正常内容，`isError` 恒为 false。

代价：Dify 的"异常"分支不会触发，工作流里要用 `ok == false` 判断。

### 3.3 `post_json`

`post_json` 同样在 `apps/mcp_demo/tools/common.py` 里。说白了它就是个跑腿的：
替你把请求发给上游。顺利就把结果带回来；
不顺利也把失败原因（连不上？对方拒绝？返回的不是 JSON？）打包成统一格式带回来。
不管出什么事，它都不会"半路摔跤"把整个服务带崩。

```python
async def post_json(url, payload, headers=None, timeout=None):
    try:
        async with httpx.AsyncClient(
            timeout=timeout or DEFAULT_TIMEOUT,
            trust_env=False,
        ) as client:
            resp = await client.post(url, json=payload, headers=headers or {})
    except Exception as exc:
        return None, err("UPSTREAM_UNREACHABLE", f"{type(exc).__name__}: {exc}", url)

    if resp.status_code >= 400:
        detail = resp.text
        try:
            body = resp.json()
        except Exception:
            body = {}
        message = body.get("message") or f"上游返回 {resp.status_code}"
        code = "UPSTREAM_4XX" if resp.status_code < 500 else "UPSTREAM_5XX"
        return None, err(code, str(message), detail)

    try:
        return resp.json(), None
    except Exception:
        return None, err("UPSTREAM_BAD_JSON", "上游返回非 JSON", resp.text)
```

四个要点：

1. **`AsyncClient` + `async with`**：连接用完即关；同步 `requests` 会阻塞事件循环。
2. **`trust_env=False`**：不读 `HTTP_PROXY`。机器上配了全局代理时，表现是
   "上游明明活着却连不上"，最难查。
3. **`>= 400` 时优先取上游 `message`**：`HTTP 401` 没信息，`token 无效` 才能指导下一步。
4. **200 也要防非 JSON**：网关返回 HTML 错误页时 `resp.json()` 会抛，这里归一成 `UPSTREAM_BAD_JSON`。

### 3.4 错误码映射

| 上游情况 | code | message |
|---|---|---|
| 连接失败 / 超时 / DNS | `UPSTREAM_UNREACHABLE` | 含异常类型 |
| 4xx | `UPSTREAM_4XX` | 上游原文 |
| 5xx | `UPSTREAM_5XX` | 上游原文 |
| 200 但非 JSON | `UPSTREAM_BAD_JSON` | "上游返回非 JSON" |
| 200 但 `body.code != 200` | `UPSTREAM_REJECTED` | 上游 `message` |
| 业务空结果 | `EMPTY_RESULT` | "上游返回空结果" |

这张表决定模型的自愈行为：`UPSTREAM_4XX` 会改参数，`UPSTREAM_UNREACHABLE` 会建议重试，
`EMPTY_RESULT` 不会误判成"没问题"。

### 3.5 截断

`truncate` 还是在 `apps/mcp_demo/tools/common.py` 里，干的活很简单：
结果太长就剪短，并附一张"已截断，原文多少字"的纸条。
免得下游被撑爆，模型又以为"内容本来就这么点"。

```python
def truncate(text: str, limit: int | None = None) -> tuple[str, bool]:
    limit = limit or MAX_TEXT_CHARS
    text = text or ""
    if len(text) <= limit:
        return text, False
    return f"{text[:limit]}\n…（已截断，原文 {len(text)} 字）", True
```

只截断不标注 → 模型以为"内容就这么点"；只标注不截断 → 下游被撑爆。
所以返回元组，调用方必须把 `truncated` 放进结果。

### 3.6 基址与健康检查

`apps/mcp_demo/tools/common.py` 里的这张"通讯录"，
记着每类上游服务的地址存在哪个环境变量里、
没配置时默认用哪个端口。换服务时只改这张表，别处的代码一行不动。

```python
_SERVICE_ENV = {
    "sync": ("UPSTREAM_SYNC_BASE", 7300),
    "task": ("UPSTREAM_TASK_BASE", 7300),
}
```

健康检查要求：**永不抛异常**、**超时短**（8s）。排障时它必须立刻给结论。

### 3.7 换成你的服务时

| 位置 | 改什么 |
|---|---|
| `_SERVICE_ENV` | 环境变量名 + 默认端口 |
| `DEFAULT_TIMEOUT` / `MAX_TEXT_CHARS` | 按上游耗时、Dify 节点上限调 |

`common.py` **不允许出现业务字段**。写了 `if xxx == ...` 就说明分层塌了。

---

## 4. 封装同步接口（1.5 小时）

### 4.1 模板（`tools/sync_api.py`，可直接改成你的）

下面是 `apps/mcp_demo/tools/sync_api.py` 的全文，照着抄改成你的即可。
它是同步工具的完整样板，固定四步：① 接参数（函数签名决定模型怎么填）；
② 自己先检查一遍（缺了、超长就当场退回，不去麻烦上游）；③ 让 `post_json` 去
问上游；④ 把结果整理成统一格式交回去。失败的情况每一步都有出口，绝不会"卡死"。

```python
from apps.mcp_demo.tools.common import (
    err, get_health, ok, post_json, service_base, truncate,
)

_PATH = "/api/sync"
_HEALTH_PATH = "/api/health"
MAX_INPUT_CHARS = 20000


def register(mcp) -> None:
    @mcp.tool()
    async def sync_call(input: str, token: str) -> dict:
        """调用同步接口，一次拿到处理结果。适合耗时几十秒内的接口。

        参数：
            input  要处理的文本（必填，最多 20000 字）
            token  访问令牌（必填，demo 默认 demo-token）

        返回：
            {"ok": true, "output": "……", "length": 128, "truncated": false}
            {"ok": false, "code": "BAD_ARGS|UPSTREAM_4XX|...", "message": "……"}
        """
        input = (input or "").strip()
        token = (token or "").strip()
        if not input:
            return err("BAD_ARGS", "input 必填：随便传一段文本即可，如 hello")
        if not token:
            return err("BAD_ARGS", "token 必填：demo 默认 demo-token")
        if len(input) > MAX_INPUT_CHARS:
            return err("BAD_ARGS", f"input 过长（{len(input)} 字），上限 {MAX_INPUT_CHARS} 字")

        data, error = await post_json(
            service_base("sync") + _PATH, {"token": token, "input": input}
        )
        if error:
            return error

        if data.get("code") not in (200, None):
            return err("UPSTREAM_REJECTED", str(data.get("message") or "上游返回非成功状态"),
                       str(data)[:800])

        body = data.get("data") or {}
        output, truncated = truncate(str(body.get("output") or ""))
        if not output:
            return err("EMPTY_RESULT", "上游返回空结果", str(data)[:800])

        return ok(output=output, length=body.get("length") or len(output),
                  truncated=truncated)

    @mcp.tool()
    async def sync_health() -> dict:
        """检查同步接口是否可用（排障第一步，无参数）。"""
        result = await get_health(service_base("sync") + _HEALTH_PATH)
        return ok(service="sync", base=service_base("sync"), **result)
```

### 4.2 五个改造点

| 改哪里 | demo | 你的 |
|---|---|---|
| `_PATH` / `_HEALTH_PATH` | `/api/sync` | 你的路径 |
| 入参 | `input`、`token` | 你的字段（注意 camelCase） |
| 工具名 | `sync_call` | 动词开头、全局唯一 |
| docstring | 示例语义 | 业务语义 + 枚举 + 返回结构 |
| 校验 | 非空 + 长度上限 | 你的枚举/格式校验 |

### 4.3 逐段解析

**① 签名就是 Schema**

| 写法 | Schema 效果 | 模型行为 |
|---|---|---|
| `input: str` | `required` | 必须填 |
| `limit: int = 10` | 可选 + 默认 | 可不填 |
| `flag: bool = False` | `boolean` | 填 true/false |

不要用 `dict` / `Any` 做参数：Schema 是空对象，模型不知道填什么。

**② docstring 是提示词**，必须回答四件事：何时用、每个参数填什么（枚举直接列）、
返回什么、有什么限制。差写法只有三个字"调用接口"；好写法带触发条件与枚举。

**③ 本地校验 = 早失败 + 可自愈。** 上游也会校验，但它要跑完一次处理才报错；
本地校验把"错几十秒"变成"错 0.1 秒"，`message` 直接给出正确填法，模型能自己重试。

**④ 字段映射只做一次。** MCP 侧 `snake_case`，上游可能 `camelCase`，
转换写在组装 payload 那一处。

**⑤ 错误直接透传，业务码也要判。** `post_json` 已返回信封，`return error` 即可；
但有的上游 HTTP 200 而 `body.code=500`，必须再判一次。

### 4.4 验收：三种返回

| 场景 | 期望 |
|---|---|
| 正常 | `ok: true`，`output` 非空，`truncated: false` |
| 参数错 | `ok: false, code: BAD_ARGS`，`message` 说明怎么改 |
| token 错 | `ok: false, code: UPSTREAM_4XX`，`message` 来自上游 |

第 6 章的演练脚本 [3][4][5] 步就是这三条。

---

## 5. 封装异步接口（2~3 小时，核心）

### 5.1 先把时序钉死

先看示例上游（`apps/mcp_demo/sample_upstream.py`）接到任务后的
"动作时刻表"：先自己忙 4 秒做解析，第 4 秒才把活儿交给后台；SSE 通道只在
第 4 秒前后说一句话，之后只剩进度播报。

```
t=0      POST /api/tasks/upload → 200 + 响应头 X-Task-Id，正文是 SSE
t=0~4s   解析资源 —— 在当前请求进程内（SAMPLE_SUBMIT_DELAY）
t=4s     提交给后台任务引擎，job_id 产生（只写在 meta 里）
         SSE 只发一条"任务已提交，任务ID: 3f2a1b..."（截断 12 位）
t=4~10s  后台执行，接口层只转发进度（SAMPLE_TOTAL_DELAY）
t=10s    收尾：生成结果文件 → completed
```

两条硬结论（整个第 5 章都围绕它们）：

1. **t<4s 断开 → 任务没提交**：生成器被取消，永远不会有 job_id；
2. **SSE 事件里没有完整 job_id**：所以不能靠"读到某个事件"判断已提交。

### 5.2 亲手复现一次

不写代码，先用 curl 体验（这是 probe 存在的唯一原因）：

这个实验是故意"只听 2 秒就挂电话"，然后回拨查岗——看任务是被取消了
（说明挂早了），还是还在正常跑。这是后面所有设计的出发点。

```bash
# 只读 2 秒就断开（(28) 超时提示属正常，故 2>/dev/null）
TASK=$(curl -sS -D - -o /dev/null --max-time 2 2>/dev/null \
  -X POST http://127.0.0.1:7300/api/tasks/upload \
  -F use_resource=true -F resource_id=res-demo-001 -F token=demo-token \
  | tr -d '\r' | awk 'tolower($1)=="x-task-id:"{print $2}')
echo "task=$TASK"

curl -sS "http://127.0.0.1:7300/api/tasks/$TASK" | python3 -m json.tool
```

实测：

```text
task=dd5413530216
{'status': 'cancelled', 'job_id': ''}
```

把 `--max-time 2` 改成 `6`（跨过 4 秒提交点）：

```text
task=0ae6d943df56
{'status': 'processing', 'job_id': 'd9327bbfeffa445e'}
```

**同一个接口，断开时机不同，结果完全相反。**

### 5.3 错误写法 vs 正确写法

先看错误写法，这是"傻等"版：一直等对面把全部话说完才挂线，
中途什么都干不了，也搞不清对面到底开没开口。

```python
# 错误：当普通 POST 调，等流结束才拿到响应
resp = await client.post(url, data=form)
text = resp.text           # 一直阻塞到流结束
```

没有进度、拿不到提前返回、超时断开时不知道任务提交没提交。

再看正确写法，这是"边听边办"版：一边听一边记录，
一听到"后台接手了"就挂线去干别的，任务自己在后台跑，不耽误工夫。

```python
# 正确：流式消费，边读边决定何时断
async with client.stream("POST", url, data=form) as resp:
    task_id = resp.headers.get("x-task-id", "")
    async for raw in resp.aiter_lines():
        ...
```

### 5.4 `post_form_sse` 六段

（删减版，完整实现在 `tools/common.py`，约 120 行。）

**(1) 建流 + 先取响应头**

接下来把 `apps/mcp_demo/tools/common.py` 里的 `post_form_sse` 拆成 6 段看（本章 6 段都是它）。
第 (1) 段：先把电话接通，并且在听内容**之前**就拿到"任务编号"（响应头）。
万一对方直接报错，你手里也有编号可以查岗。

```python
async with client.stream("POST", url, data=form, headers=headers or {}) as resp:
    task_id = resp.headers.get("x-task-id", "")
    if resp.status_code >= 400:
        body = (await resp.aread()).decode("utf-8", "replace")
        ...
        reason = "http_error"
        return
```

出错时正文可能只有一句话，没有 task_id 连查都没法查。httpx 会把头名规范成小写。

**(2) 逐行读，跳过心跳**

第 (2) 段：一行一行听。空行只是换行，`:` 开头的是对方报的"我还活着"心跳，
都不用处理，只认 `data:` 开头的正文。不跳过心跳，程序会把心跳当内容去解析、报错。

```python
async for raw in resp.aiter_lines():
    line = raw.strip()
    if not line or line.startswith(":"):     # 空行=帧分隔；":"=心跳
        continue
    if not line.startswith("data:"):
        continue
    payload = line[5:].strip()
    if payload in ("[DONE]", ""):
        reason = "done"
        break
```

`aiter_lines()` 按行给、不按事件给，帧格式要自己解；不跳过 `: keep-alive` 会 `json.loads` 失败。

**(3) `stop` 只能识别终态**

第 (3) 段：每听到一条消息，就问一次调用方传进来的 `stop` 函数：
"这条是不是结束信号（比如失败、完成）？"是就收线。
但"后台接手了"这件事不在消息里，所以光靠它判断不了——这就引出第 (4) 段。

```python
events.append(event)
if stop and stop(event):
    reason = "stop"
    break
```

`completed`/`failed` 在事件里；"后台已接手"不在事件里。

**(4) `probe`：每 5 秒的侧信道**

第 (4) 段：每 5 秒，趁对方沉默的空当，偷偷打给查询接口问一句
"我的活儿被后台接手了吗？"问到就收线。查询失败了就当没问过——
宁可多等，也绝不因为"没查到"就乱收线把任务弄丢。

```python
now = time.monotonic()
if probe and now - last_probe >= 5.0:
    last_probe = now
    probe_calls += 1
    try:
        hit = probe(task_id, events, now - started)
        if asyncio.iscoroutine(hit):
            hit = await hit
    except Exception:
        hit = False
    if hit:
        reason = "probe"
        break
```

5 秒节流、兼容同步/异步、异常一律当 False、`probe_calls` 用于事后核对。

**(5) 超时不抛异常**

第 (5) 段：设个闹钟。时间到了**不算"出错"**，只记一笔"没等到"——
因为很可能任务还没提交，这跟"网络挂了"是两回事，返回给模型的错误码必须不同。

```python
try:
    if total_timeout:
        await asyncio.wait_for(_consume(), timeout=total_timeout)
    else:
        await _consume()
except asyncio.TimeoutError:
    reason = "timeout"
```

超时要翻译成"任务可能没提交"，只有网络错误才是"上游不可达"。

**(6) `read_timeout` 不是总时长**

第 (6) 段：注意 `read_timeout` 管的是"两次说话之间最长能沉默多久"，不是整通电话的时长。
所以解析阶段几分钟不吭声，也得把这条线放宽，不然健康的任务会被误判死亡。

```python
timeout = httpx.Timeout(read_timeout, connect=30.0, write=60.0, pool=30.0)
```

它是"两次收到数据之间"的上限。解析阶段可能几分钟没有事件，
`task_api.py` 传 300 秒；用默认 90 秒会把健康任务判死。

### 5.5 `probe` 怎么写

`probe` 写在 `apps/mcp_demo/tools/task_api.py` 里，做的事情就一件：
拿任务编号去问上游"这活儿后台接了没"。
三条纪律：没编号不问；问失败当没问；只有确认接手了（查到 job_id）才喊停。

```python
async def _probe(task_id: str, _events, _elapsed) -> bool:
    if not task_id:
        return False
    body, error = await get_json(f"{TASKS_URL}/{task_id}", timeout=15.0)
    if error:
        return False
    return bool(((body or {}).get("data") or {}).get("job_id"))
```

三条硬约定：

1. 没 `task_id` → False；
2. 查询失败 → False（宁可不提前断，不能误断）；
3. 签名与 `common.py` 的调用一致：`probe(task_id, events, elapsed)`。

第 3 条是最隐蔽的坑：调用方传 2 个参数、实现收 3 个 → `TypeError` 被 `except` 吞掉 →
表现是"永远等满超时"，日志里什么都没有。兜底：类型注释 + 返回 `probe_calls`（0 就是没探测）。

### 5.6 断开后补查一次 meta

`probe` 返回 True 到函数返回之间有几毫秒，任务可能已完成（小任务会碰到）。
所以 `apps/mcp_demo/tools/task_api.py` 里在断开后又补查了一次状态——
万一它刚好在最后一秒跑完了，就能直接把结果一并带走，省得模型再轮询一圈。

```python
meta = {}
body, error = await get_json(f"{TASKS_URL}/{task_id}", timeout=15.0)
if not error:
    meta = (body or {}).get("data") or {}

if status == "completed":
    return ok(..., detached=False, ...)
```

### 5.7 状态机：每种 status 都要有出口

| `status` | 返回 | 说明 |
|---|---|---|
| `completed` | `ok(detached=False)` + 结果文件 + 截断 output | 任务比 probe 快 |
| `failed` / `error` | `err("TASK_FAILED", 上游 output)` | 上游明确失败 |
| `cancelled` | `err("TASK_CANCELLED", "连接断开过早，请重新发起")` | 断在提交前 |
| `processing` 且有 job_id | `ok(detached=True, probe_calls=...)` | 正常提前返回 |
| `uploaded` 且无 job_id | `err("SUBMIT_TIMEOUT"/"SUBMIT_INCOMPLETE")` | 没确认提交 |

### 5.8 两种模式

| | `wait=false`（默认） | `wait=true` |
|---|---|---|
| `probe` | 每 5s 查 meta.job_id | 不传，只靠 `stop` |
| 返回时机 | job_id 出现即断开（约 5s） | 任务真正结束（约 10s） |
| 结果文件 | 拿不到（收尾才生成） | 能拿到 |
| 适用 | Dify 工作流 + 轮询 | 后台任务、离线批处理 |

### 5.9 三个必测

| 场景 | 期望 |
|---|---|
| `wait=false` | `detached: true`、`probe_calls >= 1`、约 5s 返回 |
| `submit_timeout=2` | `TASK_CANCELLED`（或 `SUBMIT_TIMEOUT`），`job_id` 为空 |
| `wait=true` | `status: completed`、`result_file_id` 非空 |

### 5.10 五种写错的样子

| 错误 | 现象 |
|---|---|
| `probe` 签名不匹配 | 永远等满超时，`probe_calls=0` |
| 用 `stop` 匹配"任务ID"文本 | 只有 12 位截断 ID，上游改文案就失效 |
| `probe` 命中却不断开 | 长连接占着，客户端读超时后照样断 |
| `probe` 查失败返回 True | 解析阶段被误断，任务从未提交 |
| 只判 status 不补查 meta | 恰好完成的任务结果丢失 |

### 5.11 形态 3 与形态 4 的差别（最容易混）

| | 形态 3 SSE + 后台任务 | 形态 4 纯流式（边算边吐） |
|---|---|---|
| 断开后 | 后台任务继续跑，可用 ID 续查 | 结果直接丢弃，只能重来 |
| 何时可断 | job_id 出现后 | 只有读到结束（`done`/`[DONE]`） |
| `probe` | 必须有 | **必须删掉**（查不到状态，只会白等） |
| `stop` | 只认 `failed`/`error` | 认 `done` |
| 重试 | 提交前可重试；提交后重发会产生重复任务 | 可以整体重试 |

形态 4 的调用参数就这两处不同：

如果你的上游是"边算边吐"（没有后台任务），调用参数就两处不同（这段抄到
`apps/mcp_demo/tools/task_api.py` 的调用处）：
不装探测器（`probe=None`，因为没有可查的状态），一直听到"讲完了"
才算拿到结果；没听到结束语，结果就当废的。

```python
result = await post_form_sse(
    url, form,
    stop=lambda e: bool(e.get("done")),   # 读到结束即完成
    probe=None,                            # 没有可查的状态，别传 probe
    read_timeout=300,
    total_timeout=wait_timeout,
)
if result["reason"] != "done":
    return err("INCOMPLETE_STREAM", "流没有正常结束，结果不可用")
```

判断标准只有一条：**断开之后还能不能查到任务**。能查到就是形态 3，查不到就是形态 4。

---

## 6. 装配与自测（30 分钟）

### 6.1 注册中心

`apps/mcp_demo/tools/__init__.py` 就是一张"工具登记表"：把写了工具的文件挨个
列出来，服务启动时按表安装。以后加新工具，只需要在表里加一行，入口文件永远不用动。

```python
from apps.mcp_demo.tools import sync_api, task_api

_MODULES = (sync_api, task_api)      # 顺序 = tools/list 的顺序


def register_all(mcp) -> list[str]:
    for mod in _MODULES:
        mod.register(mcp)
    return [mod.__name__.rsplit(".", 1)[-1] for mod in _MODULES]
```

约定：每个业务模块只暴露 `register(mcp)`，装饰器写在 `register` 内部。
`main.py` 永远不用改。

### 6.2 入口

`apps/mcp_demo/main.py` 是服务的总开关，只干三件事：给自己起名（顺带一句话自我介绍）、
把登记表里的工具全装上、开门营业（run）。

```python
mcp = FastMCP(
    "mcp-demo",
    instructions="示例 MCP 服务：同步 sync_call；异步 task_submit → task_status。",
    host=HOST, port=PORT,
    streamable_http_path="/mcp",
    sse_path="/sse",
    json_response=JSON_RESPONSE,
    stateless_http=STATELESS,
    log_level=os.getenv("MCP_LOG_LEVEL", "INFO"),
)

REGISTERED = register_all(mcp)


def main() -> None:
    mcp.run(transport=TRANSPORT)
```

| 参数 | 取值 | 说明 |
|---|---|---|
| `streamable_http_path` | `/mcp` | Dify 的 URL 必须与它一致 |
| `json_response` | `True` | curl 直接看 JSON，调试期必开 |
| `stateless_http` | `True` | 不校验会话 ID，多副本/短连接更稳 |

`instructions` 会随 `initialize` 返回，部分客户端会拼进系统提示；用一两句话说清
"有哪些工具、异步怎么串"，能降低乱选工具的概率。

### 6.3 启动验收

把服务手动开起来，看第一行日志有没有把登记表里的模块都列出来。

```bash
MCP_PORT=7301 python3 -u -m apps.mcp_demo.main
```

期望：

```text
[mcp-demo] modules=['sync_api', 'task_api'] transport=streamable-http endpoint=http://127.0.0.1:7301/mcp
```

`modules` 少一个 → 注册清单漏了；`modules=[]` → import 失败（直接
`python3 -c "import apps.mcp_demo.tools.task_api"` 看堆栈）。

### 6.4 端到端自测

一条命令就能把示例上游和 MCP 服务都开起来，自动跑完 8 步考题，结束自动收摊。
加 `--keep` 就是不收摊，留着给 Dify 连。

```bash
cd /Users/cqj/Documents/agent_learning_orginal/agent_learning
python3 -m apps.mcp_demo.run_demo        # 起两个服务 + 跑 8 步 + 自动收
python3 -m apps.mcp_demo.run_demo --keep # 保留服务，供 Dify 连接
```

| 步骤 | 预期 | 不符合说明什么 |
|---|---|---|
| [1] tools/list | 6 个工具 | 注册漏了 / docstring 写废了 |
| [2] 健康检查 | `ok: true` | 上游没起或基址错 |
| [3] 同步成功 | 0.8s 返回 `output` | 契约没对上 |
| [4] 本地校验 | `BAD_ARGS`，上游无日志 | 校验没生效 |
| [5] 上游 4xx | `UPSTREAM_4XX` + 上游 message | 错误被吞了 |
| [6] 异步断开 | `detached: true`、`probe_calls >= 1`、约 5s | `probe` 没跑（5.5） |
| [7] wait=true | 拿到 `result_file_id` | 流被提前断开 |
| [8] 断太早 | `TASK_CANCELLED`，`job_id` 空 | **最危险**：断连语义没复现 |

### 6.5 常驻

下面这个配置文件是写给 Linux 的 systemd"保姆"看的：
开机自启、进程崩了 3 秒后自动拉起来，不用人守着。

```ini
# /etc/systemd/system/mcp-demo.service
[Unit]
Description=MCP Demo Service
After=network-online.target

[Service]
WorkingDirectory=/opt/agent_learning
Environment=MCP_HOST=0.0.0.0
Environment=MCP_PORT=7301
ExecStart=/usr/bin/python3 -m apps.mcp_demo.main
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now mcp-demo
sudo systemctl status mcp-demo --no-pager
```

---

## 7. 换成你的服务（主菜）

### 7.1 替换顺序：从只读开始，风险最低

1. **改健康检查**：只换基址，验证网络与鉴权；
2. **改只读工具**：`task_status`、`task_list`，验证字段映射；
3. **改写工具**：`sync_call`、`task_submit`，验证业务与错误分支；
4. **删掉示例**：`sample_upstream.py`、`demo_client.py` 里的示例断言、`run_demo.py`；
5. **改描述**：工具名、docstring、`instructions`、服务名。

不要一次性全改完再跑——出错时分不清是网络、字段还是业务。

### 7.2 改动清单

| 文件 | 改什么 | 不改什么 |
|---|---|---|
| `tools/common.py` | `_SERVICE_ENV`（变量名/端口）、超时、截断上限 | 四个函数体 |
| `tools/sync_api.py` | `_PATH`、入参、取值、工具名、docstring | `register(mcp)` 结构 |
| `tools/task_api.py` | 路径、表单字段、状态机取值、`probe` 判据 | `post_form_sse` 调用方式 |
| `tools/__init__.py` | `_MODULES` | `register_all` |
| `main.py` | 服务名、`instructions` | 其余 |
| `sample_upstream.py` | 直接删除（换成真上游） | — |

### 7.3 契约映射表（逐行对）

| demo | 你的 | 改在哪 |
|---|---|---|
| `POST /api/sync` | 你的同步接口 | `sync_api.py: _PATH` |
| `{"token","input"}` | 你的 JSON 字段 | `sync_api.py: payload` |
| `data.output` | 你的结果字段 | `sync_api.py: body.get(...)` |
| `X-Task-Id` | 你的任务 ID 位置 | `common.py: resp.headers.get` |
| `use_resource/resource_id` | 你的表单字段 | `task_api.py: form` |
| `data.job_id` | 你的"已接手"标志 | `task_api.py: _probe` |
| `data.output/item_count` | 你的结果字段 | `task_api.py: status 分支` |
| `data.result_file_id` | 你的附件字段 | `task_api.py: completed 分支` |

参数名可以自由改（`task_id` → `order_no` 也行），但改名时必须三处同步：
函数签名、docstring 的返回示例、映射到上游的那一行。漏掉 docstring 是最常见的，
模型会按旧字段名理解返回。

### 7.4 五种常见改造场景

**A. 上游是普通异步（POST 返回 task_id，另查状态），没有 SSE**

不要用 `post_form_sse`，直接两次 `post_json` / `get_json`：

上游没有 SSE 时反而更简单：新建一个 `tools/<你的域>.py`，只用到 `post_json`，
完全不碰 SSE。思路是把活儿交出去、拿到单号（task_id）
就返回，等结果的事交给 Dify 轮询。千万别在工具里死等——Dify 会先超时。

```python
@mcp.tool()
async def submit(input: str, token: str) -> dict:
    """提交后台任务，立即返回 task_id；结果用 task_status 查。"""
    data, error = await post_json(
        service_base("task") + "/api/submit",
        {"input": input, "token": token},
    )
    if error:
        return error
    task_id = str(((data or {}).get("data") or {}).get("task_id") or "")
    if not task_id:
        return err("NO_TASK_ID", "上游未返回 task_id", str(data)[:500])
    return ok(task_id=task_id, hint="用 task_status(task_id) 轮询")
```

关键：提交接口必须快速返回，绝不在 MCP 里等结果；轮询交给 Dify 工作流。

**B. 是 SSE，但完整 task_id 在第一个事件体里**

改 `post_form_sse` 的取值处（或在 `task_api.py` 里先读事件）：

如果是 SSE、但完整编号写在第一条消息里，那就改 `apps/mcp_demo/tools/common.py`
的 `post_form_sse`，听到的顺手记下来，
后面连"查户口"（probe）都省了。

```python
if not task_id and event.get("task_id"):
    task_id = str(event["task_id"])
```

有完整 ID 就不用 probe 查 meta，但仍要确认"已提交"事件——别断在解析阶段。

**C. 鉴权放在 header**

鉴权放在请求头（相当于把令牌从"信纸"挪到"信封"上），调用方式就这一处差别，
改在 `apps/mcp_demo/tools/sync_api.py` 或 `task_api.py` 的调用处。

```python
data, error = await post_json(
    url, payload, headers={"Authorization": f"Bearer {token}"}
)
```

docstring 里写明"token 由调用方传入，不要写死"，且不要回显 token。

**D. 返回结构嵌套**

上游返回的结果包了好几层"盒子"，就在 `apps/mcp_demo/tools/sync_api.py` 的取值处
拆到最里层，把真正要用的内容取出来。

```python
result = ((data.get("data") or {}).get("result")) or {}
output = result.get("content", "")
```

同步改 docstring 的返回示例，否则模型仍按旧字段名理解。

**E. 同步接口很慢（>60s）**

上游慢就多等：在 `apps/mcp_demo/tools/sync_api.py` 的调用处把这一次请求的
闹钟单独调大到 300 秒，别的请求不受影响。

```python
data, error = await post_json(url, payload, timeout=300)
```

并把 Dify 的 SSE 读取超时调大（第 8.4 节）。更稳的是让上游提供异步接口；
没有异步但**有进度接口**时，可封装成"提交 + 查询进度"两件套。

### 7.5 回归六条（换完必须全过）

1. 正常路径返回业务字段；
2. 参数错在本地被拦（上游日志无记录）；
3. token 错返回 `UPSTREAM_4XX`，`message` 是上游原文；
4. 断网返回 `UPSTREAM_UNREACHABLE`，服务不崩；
5. 超长结果被截断且 `truncated=true`；
6. 异步：`detached=true`、`probe_calls>=1`、断太早为 `TASK_CANCELLED`。

### 7.6 反模式

| 反模式 | 为什么不行 |
|---|---|
| 在 `common.py` 里写业务判断 | 分层塌了，换业务要动公共层 |
| 工具里打印 token | 泄密，且日志会被采集 |
| 原样返回上游 JSON | 字段对 LLM 不友好，Schema 不稳定 |
| 一个工具塞 10 个 action | Schema 形同虚设，模型选不准 |
| `except: pass` 包住 probe | 静默失败，永远等满超时 |
| 超时设成不限 | 断连语义全乱，任务可能永远挂起 |

---

## 8. 接入 Dify（1 小时）

整件事就五步，先照着走一遍，卡住了再翻后面的细节：

```
① 起服务          python3 -m apps.mcp_demo.run_demo --keep
② Dify 添加 MCP   「工具」页 → MCP → 添加，URL 填 http://<宿主机IP>:7301/mcp
③ 拉取工具        点「获取工具」，应列出 6 个
④ 先跑 health     工作流里只挂 sync_health，跑一次，确认全链路通
⑤ 挂业务工具      同步挂 sync_call；异步挂 task_submit → 轮询 task_status
```

每一步的细节：② 见 8.1（字段怎么填）；③ 失败见 8.7；④ 的四种结果见 8.2；
⑤ 的工作流画法见 8.5；超时报错见 8.4。

### 8.1 添加 MCP 服务

「工具」页 → **MCP** → **添加 MCP 服务 (HTTP)**

| 字段 | 填什么 | 注意 |
|---|---|---|
| 名称和图标 | `MCP Demo` | 任意 |
| 服务器标识符 | `mcp-demo` | 小写字母/数字/`_`/`-`，≤24 字符，空间内唯一 |
| 服务端点 URL | `http://<宿主机IP>:7301/mcp` | **必须 `/mcp` 结尾** |
| 认证 | 无 | 有 token 时填请求头 |
| 请求头 | 留空 | 如 `Authorization: Bearer xxx` |
| 超时时间 | `30` | 连接 + 普通 HTTP |
| SSE 读取超时时间 | `900` | 见 8.4 |

点「添加并授权」→「获取工具」→ 应列出 6 个工具。

### 8.2 先只验健康检查

第一次接，不要一上来就用写工具。先在工作流里只挂 `sync_health`，跑一次：

| 结果 | 结论 | 下一步 |
|---|---|---|
| `ok: true` | 网络 + 协议 + 上游全通 | 挂业务工具 |
| 503 / 连接超时 | 网络层 | 第 9 章 |
| `ok: false, UPSTREAM_UNREACHABLE` | MCP 活着，上游没起 | 查基址环境变量 |
| 工具列表为空 | 端点错或 URL 结尾不对 | 回到 8.3 |

### 8.3 URL 结尾决定传输方式

- `/mcp` → Streamable HTTP（推荐）
- `/sse` → 老式 SSE（对应 `MCP_TRANSPORT=sse`）
- 其它路径 → 先试 SSE 再回退，多一次握手，更容易超时

### 8.4 三个超时

| 参数 | 默认 | 语义 | 建议 |
|---|---|---|---|
| 超时时间 | 30s | 连接 / 普通 HTTP | 30 |
| SSE 读取超时时间 | 300s | **两次收到数据之间的间隔** | 900（解析可能 600s 无事件） |
| 工作流整体上限 | 1200s | 单次工作流总时长 | 与轮询次数匹配 |

```
Dify SSE 读取超时  ≥  上游最长"无事件间隔" + 120s
工具 submit_timeout ≤  Dify SSE 读取超时 - 30s
工作流整体上限     ≥  轮询次数 × 间隔 + 单次工具耗时
```

### 8.5 工作流怎么串

**同步版**

```
[开始] → [工具: sync_call] → [代码: 解析 text] → [LLM 总结] → [结束]
```

**异步版**

```
[开始] → [工具: task_submit(wait=false)] → [代码: 取 task_id]
        → [循环: 最多 30 次]
             ├─ [工具: task_status(task_id)]
             ├─ [代码: 判断 status]
             └─ completed/failed/cancelled → 退出
        → [LLM: 用 output + item_count 组织结果] → [结束]
```

两处必须做：先看 `ok`，再看 `status`，最后才读 `output`；轮询设上限（20~40 次、间隔 30s）。

**Agent 应用（不想搭工作流的省事版）**

创建应用时选「Agent」→ 工具里勾选 `mcp-demo` 下的工具 → 发布 →
直接在对话框里说"帮我处理这段文本：……"，模型会自己挑工具、自己填参数。
`task_submit` 的 docstring 里写了"结果用 task_status 查"，模型通常会自己接着轮询。

Agent 版适合演示和验证，生产建议用工作流版：轮询次数、失败分支、超时都可控，
不会被模型"发挥"。

**调用起来后怎么确认是真通了**：Dify 日志里看工具节点的输入输出；
MCP 服务的终端会同步打出每次调用。两边都有记录，才是真的调用成功。

### 8.6 工具输出怎么解析

MCP 工具节点输出通常是 `text`（字符串形式的 JSON），用代码节点转换：

下面这段是给 Dify 工作流里「代码节点」用的（不属于本仓库，直接粘进去）。
MCP 给 Dify 的结果是一整段字符串（信封套着信封），这段代码就是
拆信封：把 ok、task_id、status 这些字段拆成独立变量，后面的节点才好引用。

```python
import json

def main(text: str) -> dict:
    data = json.loads(text)
    return {
        "ok": data.get("ok", False),
        "task_id": data.get("task_id", ""),
        "status": data.get("status", ""),
        "output": data.get("output", ""),
        "truncated": data.get("truncated", False),
    }
```

若你的 Dify 版本按 outputSchema 展开字段，直接用 `result.xxx`，逻辑一样。

**不要**把 `text` 直接当正文丢给 LLM：失败时里面是 `{"ok": false, "message": ...}`。

### 8.7 接入失败对照

| 现象 | 原因 | 确认方式 |
|---|---|---|
| 「获取工具」失败 | URL 结尾不对 / 服务没起 | `curl ... tools/list` |
| 503，本机正常 | 容器网络 / 防火墙 | 第 9 章 |
| 连接超时 | 用了 `127.0.0.1` | 换宿主机 IP |
| 调用报参数错 | 参数名与 Schema 不符 | 对照 `inputSchema` |
| 300s 后断开 | Dify SSE 超时太小 | 调 900 |
| 成功但结果为空 | 读了错误字段 | 用 8.6 解析 |
| `isError: true` | 工具内部抛异常 | 看 MCP 日志 traceback |

---

## 9. 上线检查单

### 9.1 网络四步

排查网络问题从近到远一段段来：① 先确认本机通；② 再确认容器能连到宿主机；
③ 再确认走 Dify 的代理也能通；④ 都不行就看代理的"流水账"（日志）。
哪一段断的一目了然，不用瞎猜。

```bash
HOST_IP=192.168.x.x
PORT=7301

# ① 本机正常？
curl -sS -o /dev/null -w '%{http_code}\n' -X POST "http://127.0.0.1:$PORT/mcp" \
  -H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'

# ② 容器直连宿主机
docker exec docker-api-1 curl -sS -o /dev/null -w 'HTTP=%{http_code}\n' \
  --max-time 5 --noproxy '*' "http://$HOST_IP:$PORT/mcp" -X POST \
  -H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'

# ③ 经 squid 代理
docker exec docker-api-1 curl -sS -o /dev/null -w 'HTTP=%{http_code}\n' \
  --max-time 10 -x http://ssrf_proxy:3128 "http://$HOST_IP:$PORT/mcp" -X POST \
  -H 'Content-Type: application/json' -H 'Accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'

# ④ squid 日志
docker exec docker-ssrf_proxy-1 sh -c 'tail -5 /var/log/squid/access.log'
```

### 9.2 判读与放行

| 现象 | 含义 | 处理 |
|---|---|---|
| 立刻 503 | squid 能连但上游拒绝/不可达 | 核对端口与监听地址 |
| 等数十秒后 503 | 包被防火墙丢弃（超时） | 放行端口 |
| 000 / refused | 宿主机没监听 | 看 MCP 日志 |
| ②通③不通 | squid 或防火墙 | 看 ④，`TCP_MISS_TIMEDOUT` 即丢包 |

这一步是告诉防火墙"7301 端口放行"，Dify 发来的请求才进得来。

```bash
sudo ufw allow 7301/tcp comment 'MCP demo (Dify)'
sudo ufw status | grep 7301
```

### 9.3 安全清单

| 项 | 做法 |
|---|---|
| 鉴权 | MCP 前挂 header 校验（Nginx/中间件），Dify 侧配请求头 |
| token 不外泄 | 只透传，不落日志、不写错误 message |
| 暴露面 | 只在内网/容器网段可达 |
| 限流 | 按上游并发上限设 |
| 截断 | `MCP_MAX_TEXT_CHARS` 按 Dify 节点上限设 |
| 依赖固定 | `requirements.txt` 锁版本，避免 SDK 升级改 Schema |

### 9.4 观测

| 指标 | 怎么看 | 告警 |
|---|---|---|
| 工具耗时 | 服务/网关日志 | P95 超过上游 SLA |
| 错误码分布 | 统计 `code` | `UPSTREAM_UNREACHABLE` 连续出现 |
| `probe_calls=0` 占比 | 业务返回 | 非 0 说明断连逻辑退化 |
| 任务积压 | 上游任务表 | 堆积说明容量不足 |

---

## 10. 排障（按症状找）

| 症状 | 原因 | 确认 | 修法 |
|---|---|---|---|
| `No module named 'apps'` | 工作目录不对 | `pwd` | `cd agent_learning` |
| `No module named 'mcp'` | 依赖没装 | `pip show mcp` | 装 `requirements.txt` |
| `modules=[]` | 注册清单为空 | 启动日志 | 改 `_MODULES` |
| 工具少了 | 模块 import 失败 | `python3 -c "import apps.mcp_demo.tools.task_api"` | 修 import |
| 调用报参数错 | Schema 与参数不符 | `tools/list` | 改签名/docstring |
| 等满 `submit_timeout` | `probe` 没生效 | 看 `probe_calls` | 修签名 |
| `TASK_CANCELLED` | 断开早于提交 | 看 `last_progress` | 调大 `submit_timeout` |
| `SUBMIT_TIMEOUT` | 同上 | 同上 | 同上 |
| `NO_TASK_ID` | 上游没给 `X-Task-Id` | `curl -i` 上游 | 改取头字段 |
| `BAD_ARGS` | 入参不合法 | 读 `message` | 按提示改 |
| `UPSTREAM_4XX` | token/路径/参数错 | 手工 curl 上游 | 修参数 |
| `EMPTY_RESULT` | 上游 200 但无内容 | 看 `detail` | 查上游 |
| Dify 503 | 防火墙/代理 | 9.1 | 放行 |
| Dify 超时 | IP 或 SSE 超时 | 8.4 | 改 IP/调大 |
| 结果读不到 | 读了 `content` 而非 `text` | 打印原始返回 | 8.6 |

---

## 附录

### A 文件与工具

| 文件 | 作用 | 暴露的工具 |
|---|---|---|
| `main.py` | 入口：配置 + 注册 + run | — |
| `tools/common.py` | 信封/超时/截断/三种调用 | — |
| `tools/sync_api.py` | 同步范式模板 | `sync_call`、`sync_health` |
| `tools/task_api.py` | 异步范式模板 | `task_submit`、`task_status`、`task_list`、`task_health` |
| `sample_upstream.py` | 示例上游（换成真上游后删除） | — |
| `minimal_example.py` | 30 行协议验证 | `echo` |
| `demo_client.py` | 8 步端到端演练 | — |
| `run_demo.py` | 一键起服务并演练 | — |

### B 环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `MCP_PORT` | `7301` | MCP 监听端口 |
| `MCP_HOST` | `127.0.0.1` | 监听地址（容器访问改 `0.0.0.0`） |
| `MCP_TRANSPORT` | `streamable-http` | 可选 `sse` |
| `MCP_JSON_RESPONSE` | `1` | `0` 走 SSE 响应 |
| `MCP_STATELESS` | `1` | `0` 开启会话保持 |
| `MCP_LOG_LEVEL` | `INFO` | 日志级别 |
| `MCP_MAX_TEXT_CHARS` | `12000` | 截断长度 |
| `UPSTREAM_TIMEOUT` | `60` | 上游默认超时 |
| `UPSTREAM_SYNC_BASE` | `http://127.0.0.1:7300` | 同步基址 |
| `UPSTREAM_TASK_BASE` | `http://127.0.0.1:7300` | 异步基址 |
| `UPSTREAM_PORT` | `7300` | 示例上游端口 |
| `MCP_URL` | `http://127.0.0.1:7301/mcp` | 客户端连接地址 |
| `SAMPLE_SUBMIT_DELAY` | `4` | 示例上游：提交前耗时 |
| `SAMPLE_TOTAL_DELAY` | `10` | 示例上游：总耗时 |
| `SAMPLE_TOKEN` | `demo-token` | 示例上游有效 token |
| `SAMPLE_REPEAT` | `1` | 重复结果，测截断 |

### C 命令

日常用到的命令都在这，从上到下依次是：装依赖、一键演练、
只验协议、分开起两个服务、只跑客户端、查端口和清理。

```bash
cd /Users/cqj/Documents/agent_learning_orginal/agent_learning

python3 -m pip install -r apps/mcp_demo/requirements.txt

python3 -m apps.mcp_demo.run_demo            # 一键演练
python3 -m apps.mcp_demo.run_demo --keep     # 保留服务供 Dify 连接
python3 -m apps.mcp_demo.minimal_example     # 只验协议（7399）

# 分开起
python3 -m uvicorn apps.mcp_demo.sample_upstream:app --port 7300 --log-level warning
MCP_PORT=7301 python3 -u -m apps.mcp_demo.main

# 只跑客户端
python3 -m apps.mcp_demo.demo_client

lsof -nP -iTCP:7301 -sTCP:LISTEN
pkill -f apps.mcp_demo
```

### D 改造速查

| 你的接口特征 | 改哪里 | 注意 |
|---|---|---|
| 同步 JSON，秒级返回 | `tools/sync_api.py` | 只改路径与字段 |
| 同步 JSON，几十秒 | 同上 + `timeout` | Dify SSE 超时同步调大 |
| SSE + 响应头 task_id | `tools/task_api.py` | 保持 `probe` |
| SSE + 事件体带 task_id | `common.py: post_form_sse` | 加一行取 ID |
| 提交+轮询（无 SSE） | 7.4 场景 A | 不要用 `post_form_sse` |
| header 鉴权 | `post_json(..., headers=...)` | 不回显 token |
| 返回嵌套 | 改取值 + docstring | 两处必须同时改 |
| 文件入参 | 改传资源 ID / URL | base64 仅限小文件且模型不参与构造 |
| 分页列表 | 工具只回前 N 条 | 带 `total` |

