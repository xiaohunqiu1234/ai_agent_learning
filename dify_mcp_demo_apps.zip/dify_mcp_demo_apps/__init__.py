"""让 apps 成为一个显式包，`python -m apps.mcp_demo.main` 在项目根目录可直接运行。"""
